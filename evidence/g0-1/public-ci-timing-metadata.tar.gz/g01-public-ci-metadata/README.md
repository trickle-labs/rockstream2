# Public GitHub timing metadata

Collected 2026-11-28 for the four run IDs below. Each `run.json` and
`jobs.json` is the unmodified JSON response returned by `gh api`. The current
GitHub response can later differ as repository and PR metadata changes; the
saved timestamps and run/job identities are the historical observations.

```sh
for task_run_id in 46141046406 46144267253 46146476179 46101521940; do
  gh api "repos/trickle-labs/rockstream2/actions/runs/$task_run_id" > "$task_run_id-run.json" || exit 1
  gh api "repos/trickle-labs/rockstream2/actions/runs/$task_run_id/jobs?per_page=100" > "$task_run_id-jobs.json" || exit 1
done
```

The archive holds public run and job metadata, not job logs or credentials.
These selected runs are not a representative timing cohort.
