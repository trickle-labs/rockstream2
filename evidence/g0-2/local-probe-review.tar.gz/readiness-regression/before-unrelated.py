from types import SimpleNamespace
result = SimpleNamespace(returncode=1, stderr=b'assertion failed in unrelated setup')
old_accepts = result.returncode != 0 and b'assertion' in result.stderr
print(f'old negative-control predicate accepts unrelated assertion: {old_accepts}')
raise SystemExit(1 if old_accepts else 0)
