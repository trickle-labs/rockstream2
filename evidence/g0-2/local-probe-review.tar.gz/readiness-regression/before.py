import os
import select
import signal
import subprocess
import sys

partial = "import sys,time; sys.stdout.write('REA'); sys.stdout.flush(); time.sleep(10)"
waiter = "import select,subprocess,sys; p=subprocess.Popen([sys.executable,'-c',sys.argv[1]],stdout=subprocess.PIPE,stderr=subprocess.PIPE); select.select([p.stdout],[],[],0.25); p.stdout.readline()"
p = subprocess.Popen([sys.executable, '-c', waiter, partial], start_new_session=True)
try:
    try:
        p.wait(timeout=1)
        print('partial stdout: unexpected completion')
    except subprocess.TimeoutExpired:
        print('partial stdout: old select/readline exceeded 1-second outer deadline')
finally:
    os.killpg(p.pid, signal.SIGKILL)
    p.wait()

noisy = "import sys,time; sys.stderr.write('x'*262144); sys.stderr.flush(); sys.stdout.write('READY\\n'); sys.stdout.flush(); time.sleep(10)"
p = subprocess.Popen([sys.executable, '-c', noisy], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
try:
    ready = bool(select.select([p.stdout], [], [], 0.5)[0])
    print(f'noisy stderr: old select observed READY within 0.5s: {ready}')
finally:
    p.kill()
    p.communicate(timeout=5)
if ready:
    raise SystemExit('unexpected noisy-child result')
raise SystemExit(1)
