#!/bin/sh
set -u
cd /Users/grove/.p2p/evidence/rockstream-g0-3/bad-active-depth-14 || exit 1
export QUINT_HOME=/Users/grove/.p2p/rockstream-g03-tools/quint-home
export JAVA_HOME=/opt/homebrew/opt/openjdk@21
/Users/grove/.p2p/rockstream-g03-tools/node_modules/.bin/quint verify "$PWD/protocol.qnt" --server-endpoint localhost:18878 --invariant publication --step bad_active_step --max-steps 14 --verbosity 0 >stdout.txt 2>stderr.txt
result=$?
printf '%s\n' "$result" >status.txt
exit "$result"
