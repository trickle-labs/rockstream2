# Exploratory negative-control bounds

The runner checked 11 named negative controls on the frozen model SHA-256 `4f052d1c73d18bce4331ab64c0706ac0bd7b0d8e50a81f12b252b1cc1c772650` and frozen original check script SHA-256 `95b8c9a0cdb6d0db92d553fcedd39c566d0b5901129583ccc9132d6348e818ac`. It recorded the original invariant and step for each case. Ten controls used exploratory depth 14 instead of the original depth 13; retry revalidation used its original depth 16. These are separate diagnostics, not a run of the original complete checker. The original depth-13 controls in this selection were not separately run here, and their results are not reclassified. The generation counterexample happens to have 13 transitions but was found by a depth-14 diagnostic.

Each status was 1 with `found a counterexample` and one raw ITF trace. Runner status 0 means only that all invocations finished; it is not an aggregate pass. Per-case arguments, original/diagnostic bounds, stdout, stderr, status, raw Apalache logs and traces are included. The runner uses isolated port 18920, a 2 GiB JVM heap and two active JVM processors; the runner sets no Node or native memory cap; inherited environment is not fully recorded. Tool distribution is not bundled.

| Control | Original bound | Diagnostic bound | Trace transitions |
| --- | ---: | ---: | ---: |
| `bad_catalog_step` | 13 | 14 | 14 |
| `bad_fencing_step` | 13 | 14 | 14 |
| `bad_namespace_publication_step` | 13 | 14 | 14 |
| `bad_page_base_step` | 13 | 14 | 14 |
| `bad_page_generation_step` | 13 | 14 | 13 |
| `bad_parent_step` | 13 | 14 | 14 |
| `bad_refresh_step` | 13 | 14 | 14 |
| `bad_reply_step` | 13 | 14 | 14 |
| `bad_retry_revalidation_step` | 16 | 16 | 16 |
| `bad_run_step` | 13 | 14 | 14 |
| `bad_unprotected_step` | 13 | 14 | 14 |

The fencing and refresh traces combine stale-owner fencing with namespace-fence bypass. Namespace publication combines stale protection on close with a final namespace-fence bypass. Page generation combines stale-generation upload with the final generation/protection-fence bypass. Unprotected publication bypasses both staging-protection and namespace fences. Retry revalidation combines unsafe refencing with namespace-fence bypass. The remaining traces are catalog/run context, stale page base, stale expected parent, and wrong reply. These are bounded diagnostic fault witnesses; they do not establish a complete suite or a G0.3 gate pass.
