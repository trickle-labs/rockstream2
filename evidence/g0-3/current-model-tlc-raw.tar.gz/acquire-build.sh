#!/bin/sh
set -eu
base=/Users/grove/.p2p/evidence/rockstream-g0-3/container-prep
node_ref=node@sha256:a654e335251c185023165a81c4b94aa810324ad792ce8197ca2fb9c0be43ef76
java_ref=eclipse-temurin@sha256:4cba236bc5cfd25385e028b2d5aa255e2ad561349885915222e33430d4eda149
python_ref=python@sha256:209c477b2d5268b578d813ae5a4668682b55252a5b32ad1148dd49e937119101
out=$(mktemp -d "$base/build.XXXXXXXX")
printf '%s\n' "$out"
trap 'result=$?; printf "%s\n" "$result" > "$out/status.txt"; date -u > "$out/finished.txt"' EXIT
date -u > "$out/started.txt"
shasum -a 256 "$base/Dockerfile" "$base/acquire-build.sh" "$base/inspect-image.py" > "$out/config-hashes.txt"
test "$(shasum -a 256 "$base/Dockerfile" | cut -d ' ' -f1)" = f1c9a338c1657aaf833b95b6b5354b234cefaa3d2144b6f0a44044caf5f24644
docker version > "$out/docker-version.txt" 2>&1
docker manifest inspect "$node_ref" > "$out/node-manifest.json" 2> "$out/node-manifest.stderr"
docker manifest inspect "$java_ref" > "$out/java-manifest.json" 2> "$out/java-manifest.stderr"
docker manifest inspect "$python_ref" > "$out/python-manifest.json" 2> "$out/python-manifest.stderr"
docker pull --platform linux/arm64 "$node_ref" > "$out/node-pull.stdout" 2> "$out/node-pull.stderr"
docker pull --platform linux/arm64 "$java_ref" > "$out/java-pull.stdout" 2> "$out/java-pull.stderr"
docker pull --platform linux/arm64 "$python_ref" > "$out/python-pull.stdout" 2> "$out/python-pull.stderr"
docker image inspect "$node_ref" > "$out/node-image.json"
docker image inspect "$java_ref" > "$out/java-image.json"
docker image inspect "$python_ref" > "$out/python-image.json"
python3 "$base/inspect-image.py" "$out/node-image.json" "$node_ref" > "$out/node-image-id.txt"
python3 "$base/inspect-image.py" "$out/java-image.json" "$java_ref" > "$out/java-image-id.txt"
python3 "$base/inspect-image.py" "$out/python-image.json" "$python_ref" > "$out/python-image-id.txt"
DOCKER_BUILDKIT=1 docker build --platform linux/arm64 --pull=false --no-cache --iidfile "$out/image-id.txt" - < "$base/Dockerfile" > "$out/build.stdout" 2> "$out/build.stderr"
image=$(cat "$out/image-id.txt")
docker image inspect "$image" > "$out/built-image.json"
docker history --no-trunc "$image" > "$out/built-history.txt"
shasum -a 256 "$base/Dockerfile" "$base/acquire-build.sh" "$base/inspect-image.py" > "$out/config-hashes-after.txt"
cmp "$out/config-hashes.txt" "$out/config-hashes-after.txt"
