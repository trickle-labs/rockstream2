# Proposed full and TLC runners: review required

These scripts are prepared only; do not start a campaign before independent
review and explicit coordination with the current full-model candidate. Run
one mode at a time, using the independently reviewed image ID:

```sh
sh /Users/grove/.p2p/evidence/rockstream-g0-3/container-prep/campaign/run.sh full sha256:5190102c30b439f4f4a2dfce6e99e918546614ab0d467d2775f585dd6205cf85
sh /Users/grove/.p2p/evidence/rockstream-g0-3/container-prep/campaign/run.sh tlc sha256:5190102c30b439f4f4a2dfce6e99e918546614ab0d467d2775f585dd6205cf85
```

`full` runs the exact candidate check SHA-256 `93bb20790fcb2ad25ee84cb9b87ab72155a6eb46c981efae4e15a51dd21e091d`
against frozen model `4f052d1c73d18bce4331ab64c0706ac0bd7b0d8e50a81f12b252b1cc1c772650`.
`tlc` runs the separate count script SHA-256 `f0c6e65d466dcfb604c49d511650c57986884123b7c6604bf8313d9df44abaae`.
Each run snapshots the scripts and model outside the writable output mount,
mounts them read-only, and keeps evidence in a fresh directory. The container
configuration mirrors the successful one-step smoke: no network, no ports or
socket, unprivileged UID/GID, read-only root and inputs, 2 CPUs, 4 GiB total
memory, executable 512 MiB tmpfs, and 128-process cap. JVM 2 GiB heap is
specified for the full run; TLC uses its existing explicit 512 MiB setting
and only adds processor count and user.home Java options. A 4 GiB cgroup and
512 MiB tmpfs can cause an infrastructure failure. No retries are performed.

The recording wrapper supplies `QUINT` without changing arguments: it stores
each invocation's exact argv, separate stdout/stderr, return code, timestamps,
and its own working directory and Apalache output before replaying stdout and
stderr to the original check script. TLC's generated temporary model and JSON
configuration are copied before the original count script deletes them. The
wrapper buffers each stream until the command exits, then replays stdout before
stderr; therefore cross-stream ordering differs from an unwrapped live run.
Interrupted invocations lack a completion record and are not passes. Full-suite
negative-control success is determined by the unchanged check script's actual
counterexample markers, not nonzero exit alone. Separate per-invocation outputs
must be reviewed alongside the overall result.

The validated one-step smoke used explicit IPv4. The unchanged full and count
scripts use Quint's `localhost` endpoint; its behavior in the isolated network
namespace is untested and failure must remain infrastructure evidence. The
TLC depth-tagged configuration count is distinct from symbolic exploration and
must not be promoted to full-suite or milestone qualification. Image and input
hashes, before/after container inspections, output, OOM/exit state, cleanup
and tool versions must be examined. Neither runner has been executed.
