#!/usr/bin/env python3
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

root = Path('/out/invocations')
root.mkdir(exist_ok=True)
number = len(list(root.iterdir())) + 1
work = root / f'{number:04d}'
work.mkdir()
args = ['/tools/node_modules/.bin/quint', *sys.argv[1:]]
(work / 'arguments.json').write_text(json.dumps(args, indent=2) + '\n')
(work / 'started.txt').write_text(datetime.now(timezone.utc).isoformat() + '\n')
for index, arg in enumerate(args):
    if arg.startswith('/tmp/') and (arg.endswith('.qnt') or arg.endswith('.json')):
        shutil.copyfile(arg, work / f'input-{index}-{Path(arg).name}')
with (work / 'stdout.txt').open('wb') as stdout, (work / 'stderr.txt').open('wb') as stderr:
    result = subprocess.run(args, cwd=work, stdout=stdout, stderr=stderr, check=False)
(work / 'status.txt').write_text(str(result.returncode) + '\n')
(work / 'finished.txt').write_text(datetime.now(timezone.utc).isoformat() + '\n')
for name, output in [('stdout.txt', sys.stdout.buffer), ('stderr.txt', sys.stderr.buffer)]:
    with (work / name).open('rb') as source:
        shutil.copyfileobj(source, output)
    output.flush()
sys.exit(result.returncode)
