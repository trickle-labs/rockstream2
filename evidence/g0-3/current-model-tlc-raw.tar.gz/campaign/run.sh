#!/bin/sh
set -eu
base=/Users/grove/.p2p/evidence/rockstream-g0-3/container-prep
config=$base/campaign
tools=/Users/grove/.p2p/rockstream-g03-tools
source=/Users/grove/.p2p/evidence/rockstream-g0-3/working-full-candidate/source/models/g0
count_source=/Users/grove/.p2p/rockstream-g03-root-identity/models/g0/count-states.sh
mode=${1:?full or tlc}
case "$mode" in full|tlc) ;; *) exit 2 ;; esac
image=${2:?reviewed image ID}
test "$(cat "$base/reviewed-image-id.txt")" = "$image"
case "$image" in sha256:*) ;; *) exit 2 ;; esac
out=$(mktemp -d "$base/campaign-$mode.XXXXXXXX")
snapshot=$(mktemp -d "$base/snapshot-$mode.XXXXXXXX")
printf '%s\n' "$out"
user=$(id -u):$(id -g)
mkdir "$out/inputs"
cp "$source/protocol.qnt" "$snapshot/protocol.qnt"
cp "$source/check.sh" "$snapshot/check.sh"
cp "$count_source" "$snapshot/count-states.sh"
cp "$snapshot/protocol.qnt" "$snapshot/check.sh" "$snapshot/count-states.sh" "$out/inputs/"
printf '%s\n' "$snapshot" > "$out/snapshot-dir.txt"
model=$snapshot/protocol.qnt
check=$snapshot/check.sh
count=$snapshot/count-states.sh
date -u > "$out/started.txt"
docker image inspect "$image" > "$out/image-inspect.json"
cp "$base/reviewed-image-id.txt" "$out/reviewed-image-id.txt"
python3 "$config/host-inputs.py" > "$out/host-hashes-before.txt"
shasum -a 256 "$model" "$check" "$count" > "$out/snapshot-hashes-before.txt"
docker create --pull never --platform linux/arm64 --network none --read-only --cap-drop ALL --security-opt no-new-privileges --cpus 2 --memory 4g --memory-swap 4g --pids-limit 128 --user "$user" --tmpfs /tmp:rw,nosuid,nodev,exec,size=512m,mode=1777 \
  --mount "type=bind,src=$model,dst=/candidate/protocol.qnt,readonly" \
  --mount "type=bind,src=$check,dst=/candidate/check.sh,readonly" \
  --mount "type=bind,src=$count,dst=/candidate/count-states.sh,readonly" \
  --mount "type=bind,src=$tools/node_modules,dst=/tools/node_modules,readonly" \
  --mount "type=bind,src=$tools/package-lock.json,dst=/tools/package-lock.json,readonly" \
  --mount "type=bind,src=$tools/quint-home/apalache-dist-0.62.4,dst=/cache/apalache-dist-0.62.4,readonly" \
  --mount "type=bind,src=$config,dst=/config,readonly" \
  --mount "type=bind,src=$out,dst=/out" --workdir /out --entrypoint /bin/sh "$image" /config/campaign.sh "$mode" > "$out/container-id.txt"
container=$(cat "$out/container-id.txt")
cleanup() {
  cleanup_result=$?
  trap - EXIT HUP INT TERM
  set +e
  docker rm "$container" > "$out/remove.txt" 2>&1 || cleanup_result=1
  printf '%s\n' "$cleanup_result" > "$out/overall-status.txt" || cleanup_result=1
  exit "$cleanup_result"
}
trap cleanup EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
docker inspect "$container" > "$out/container-before.json"
python3 "$config/inspect.py" "$out/container-before.json" before "$image" "$user" "$config" "$tools" "$model" "$check" "$count" "$out" "$mode" > "$out/inspect-before.txt"
set +e
docker start -a "$container" > "$out/docker.stdout" 2> "$out/docker.stderr"
result=$?
set -e
printf '%s\n' "$result" > "$out/launcher-status.txt"
docker inspect "$container" > "$out/container-after.json"
python3 "$config/host-inputs.py" > "$out/host-hashes-after.txt"
shasum -a 256 "$model" "$check" "$count" > "$out/snapshot-hashes-after.txt"
date -u > "$out/finished.txt"
test "$result" -eq 0
python3 "$config/inspect.py" "$out/container-after.json" after "$image" "$user" "$config" "$tools" "$model" "$check" "$count" "$out" "$mode" > "$out/inspect-after.txt"
cmp "$out/host-hashes-before.txt" "$out/host-hashes-after.txt"
cmp "$out/snapshot-hashes-before.txt" "$out/snapshot-hashes-after.txt"
