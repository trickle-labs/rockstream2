import copy
import json
import subprocess
import sys
import tempfile
from pathlib import Path

root = Path(__file__).parent
image, user, config, tools = 'sha256:test', '501:20', '/config-host', '/tools-host'
model, check, count, out, mode = '/m', '/c', '/t', '/o', 'full'
expected = {'/candidate/protocol.qnt': model, '/candidate/check.sh': check,
            '/candidate/count-states.sh': count, '/tools/node_modules': tools + '/node_modules',
            '/tools/package-lock.json': tools + '/package-lock.json',
            '/cache/apalache-dist-0.62.4': tools + '/quint-home/apalache-dist-0.62.4',
            '/config': config, '/out': out}
c = {'Image': image, 'Config': {'User': user, 'Entrypoint': ['/bin/sh'],
     'Cmd': ['/config/campaign.sh', mode], 'WorkingDir': '/out'},
     'HostConfig': {'NetworkMode': 'none', 'PortBindings': {}, 'ReadonlyRootfs': True,
                    'CapDrop': ['ALL'], 'SecurityOpt': ['no-new-privileges'],
                    'NanoCpus': 2000000000, 'Memory': 4 * 1024**3, 'MemorySwap': 4 * 1024**3,
                    'PidsLimit': 128, 'Tmpfs': {'/tmp': 'rw,nosuid,nodev,exec,size=512m,mode=1777'}},
     'Mounts': [{'Destination': k, 'Source': v, 'RW': k == '/out'} for k, v in expected.items()],
     'State': {'Status': 'created', 'ExitCode': 0, 'OOMKilled': False}}

def test(case, phase, should_pass):
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf8') as f:
        json.dump([case], f)
        f.flush()
        cmd = [sys.executable, str(root / 'inspect.py'), f.name, phase, image, user,
               config, tools, model, check, count, out, mode]
        result = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if (result.returncode == 0) != should_pass:
            raise RuntimeError(f'unexpected result: {result.returncode}')

test(c, 'before', True)
after = copy.deepcopy(c)
after['State']['Status'] = 'exited'
test(after, 'after', True)
for key, value in [('NetworkMode', 'host'), ('ReadonlyRootfs', False), ('Privileged', True),
                   ('PortBindings', {'1/tcp': []}), ('Memory', 0), ('CapAdd', ['SYS_ADMIN'])]:
    bad = copy.deepcopy(c)
    bad['HostConfig'][key] = value
    test(bad, 'before', False)
bad = copy.deepcopy(c)
bad['Mounts'][0]['RW'] = True
test(bad, 'before', False)
bad = copy.deepcopy(c)
bad['Mounts'][0]['Source'] = '/wrong'
test(bad, 'before', False)
for key, value in [('OOMKilled', True), ('ExitCode', 1), ('Status', 'running')]:
    bad = copy.deepcopy(after)
    bad['State'][key] = value
    test(bad, 'after', False)
print('campaign inspection fixtures passed; optimize=', sys.flags.optimize)
