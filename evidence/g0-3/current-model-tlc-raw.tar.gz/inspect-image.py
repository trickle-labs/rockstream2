import json
import sys

path, ref = sys.argv[1:]
with open(path) as f:
    c = json.load(f)[0]
if c.get('Os') != 'linux' or c.get('Architecture') != 'arm64':
    raise ValueError('image platform is not linux/arm64')
if ref not in (c.get('RepoDigests') or []):
    raise ValueError('expected immutable repository digest absent')
image = c.get('Id', '')
if not image.startswith('sha256:') or len(image) != 71:
    raise ValueError('invalid image ID')
print(image)
