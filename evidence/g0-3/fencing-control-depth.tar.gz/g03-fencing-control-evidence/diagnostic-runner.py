from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess
import sys

root = Path(__file__).resolve().parent
frozen = root.parent / 'inherited-preflight-1'
model = frozen / 'protocol.qnt'
check = frozen / 'check.sh'
quint = '/Users/grove/.p2p/rockstream-g03-tools/node_modules/.bin/quint'
assert hashlib.sha256(model.read_bytes()).hexdigest() == '4f052d1c73d18bce4331ab64c0706ac0bd7b0d8e50a81f12b252b1cc1c772650'
assert hashlib.sha256(check.read_bytes()).hexdigest() == '95b8c9a0cdb6d0db92d553fcedd39c566d0b5901129583ccc9132d6348e818ac'

# Source-derived candidate bounds, not corrections to the frozen suite.
explore = {
    'bad_run_step', 'bad_catalog_step',
    'bad_parent_step', 'bad_page_base_step', 'bad_page_generation_step',
    'bad_namespace_publication_step', 'bad_unprotected_step',
    'bad_refresh_step', 'bad_fencing_step', 'bad_reply_step',
}
unchanged = {'bad_retry_revalidation_step'}
lines = check.read_text().splitlines()
loops = [line for line in lines if line.startswith('for control in ')]
assert len(loops) == 2
controls = {}
for line in loops:
    tokens = shlex.split(line)
    assert tokens[:3] == ['for', 'control', 'in'] and tokens[-1] == 'do'
    for entry in tokens[3:-1]:
        invariant, step = entry.rstrip(';').split(':')
        assert step not in controls
        controls[step] = invariant
assert explore | unchanged <= controls.keys()
assert len(explore) == 10 and len(unchanged) == 1
assert not ({'bad_active_step', 'bad_plan_revision_step'} & (explore | unchanged))
assert 'bad_retry_revalidation_step|bad_root_page_step) bound=16' in check.read_text()

cases = []
for step in sorted(explore | unchanged):
    original = 16 if step in unchanged else 13
    bound = original if step in unchanged else 14
    args = [quint, 'verify', str(model), '--invariant', controls[step], '--step', step,
            '--max-steps', str(bound), '--verbosity', '0', '--server-endpoint', 'localhost:18920']
    cases.append({'step': step, 'original_bound': original, 'diagnostic_bound': bound, 'args': args})

if sys.argv[1:] == ['--plan']:
    print(json.dumps(cases, indent=2))
elif sys.argv[1:] == ['--execute']:
    output = root / 'results'
    output.mkdir()
    (output / 'plan.json').write_text(json.dumps(cases, indent=2) + '\n')
    env = dict(os.environ, QUINT_HOME='/Users/grove/.p2p/rockstream-g03-tools/quint-home',
               JAVA_HOME='/opt/homebrew/opt/openjdk@21', _JAVA_OPTIONS='-Xmx2g -XX:ActiveProcessorCount=2')
    for case in cases:
        work = output / case['step']
        work.mkdir()
        (work / 'arguments.json').write_text(json.dumps(case, indent=2) + '\n')
        with (work / 'stdout.txt').open('wb') as stdout, (work / 'stderr.txt').open('wb') as stderr:
            result = subprocess.run(case['args'], cwd=work, env=env, stdout=stdout, stderr=stderr)
        (work / 'status.txt').write_text(str(result.returncode) + '\n')
        print(case['step'], result.returncode, flush=True)
    (output / 'finished.txt').write_text('Diagnostic invocations completed; inspect every status and raw log.\n')
else:
    raise SystemExit('Use --plan for read-only inspection or --execute for explicitly approved diagnostic runs.')
