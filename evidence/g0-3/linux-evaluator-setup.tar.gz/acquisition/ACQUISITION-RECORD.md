# Acquisition invocation record

Working directory: `/Users/grove/.p2p/evidence/rockstream-g0-3/container-prep/evaluator-acquisition`.

Exact command in both attempts: `python3 -B acquire.py`.

The first invocation ran inside the sandbox and failed with Python `urllib.error.URLError` caused by `socket.gaierror: [Errno 8] nodename nor servname provided, or not known`. Its script-generated metadata is preserved in `asset.nn2p7j_z/metadata.json`. The original terminal traceback was returned by the execution tool and was not redirected to a file; this is a transcription of its diagnostic, not a raw log. No asset was acquired in this attempt.

The second invocation used host execution with network access and returned status 0, printing `verified archive and extracted evaluator; no execution performed`. Its script-generated evidence is in `asset.a4imifyr/metadata.json`, archive, and extracted evaluator. The raw terminal output was not redirected. Archive digest matches the separately preserved official release web result. Neither attempt executed the evaluator.
