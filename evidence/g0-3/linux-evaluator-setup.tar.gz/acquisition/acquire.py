#!/usr/bin/env python3
"""Acquire the upstream Linux ARM64 evaluator into a new task-only directory."""
import datetime
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import signal
import stat
import tarfile
import tempfile
import time
import urllib.parse
import urllib.request

URL = 'https://github.com/quint-co/quint/releases/download/evaluator%2Fv0.8.0/quint_evaluator-aarch64-unknown-linux-gnu.tar.gz'
DIGEST = 'bba4edec6fc51a0491cc54add445b7204819cbcb013bd32222f5e97c00f126ef'
MAX_ARCHIVE = 5 * 1024 * 1024
MAX_TAR = 20 * 1024 * 1024
MAX_EXECUTABLE = 16 * 1024 * 1024
DEADLINE_SECONDS = 60
SOCKET_TIMEOUT = 5
BASE = Path('/Users/grove/.p2p/evidence/rockstream-g0-3/container-prep/evaluator-acquisition')


class HTTPSRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if urllib.parse.urlsplit(newurl).scheme.lower() != 'https':
            raise ValueError('redirect must use HTTPS')
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def bounded_download(response, output, deadline, clock=time.monotonic):
    digest, total = hashlib.sha256(), 0
    while True:
        if clock() >= deadline:
            raise TimeoutError('download deadline exceeded')
        chunk = response.read(min(65536, MAX_ARCHIVE + 1 - total))
        if clock() >= deadline:
            raise TimeoutError('download deadline exceeded')
        if not chunk:
            return digest.hexdigest(), total
        total += len(chunk)
        if total > MAX_ARCHIVE:
            raise ValueError('archive exceeds limit')
        digest.update(chunk)
        output.write(chunk)


def bounded_tar(archive):
    with gzip.open(archive, 'rb') as source:
        data = source.read(MAX_TAR + 1)
    if len(data) > MAX_TAR:
        raise ValueError('decompressed archive exceeds limit')
    # Reject extended metadata before tarfile can interpret PAX/GNU extensions.
    offset = 0
    while offset + 512 <= len(data):
        header = data[offset:offset + 512]
        if header == bytes(512):
            break
        if header[156:157] not in (b'0', b'\0', b'5'):
            raise ValueError('unsupported tar member type or extended metadata')
        try:
            size = int(header[124:136].strip(b'\0 ') or b'0', 8)
        except ValueError as exc:
            raise ValueError('invalid tar member size') from exc
        if size < 0 or size > MAX_EXECUTABLE:
            raise ValueError('tar member exceeds limit')
        offset += 512 + ((size + 511) // 512) * 512
        if offset > len(data):
            raise ValueError('truncated tar member')
    return data


def extract(archive, target):
    """Accept one regular executable, optionally preceded by a root directory."""
    with tarfile.open(fileobj=io.BytesIO(bounded_tar(archive)), mode='r:') as tar:
        seen = set()
        executable = None
        for member in tar:
            name = member.name
            if name in ('', '.', './') and member.isdir():
                normalized = '.'
            elif name in ('quint_evaluator', './quint_evaluator'):
                normalized = 'quint_evaluator'
            else:
                raise ValueError(f'unexpected archive member: {name!r}')
            if normalized in seen:
                raise ValueError(f'duplicate archive member: {name!r}')
            seen.add(normalized)
            if normalized == '.':
                if not member.isdir():
                    raise ValueError('root is not a directory')
            elif not member.isfile() or member.size <= 0 or member.size > MAX_EXECUTABLE:
                raise ValueError('invalid evaluator type or size')
            else:
                executable = member
        if executable is None:
            raise ValueError('missing evaluator')
        source = tar.extractfile(executable)
        if source is None:
            raise ValueError('unreadable evaluator')
        with source, open(target, 'xb') as output:
            shutil.copyfileobj(source, output, length=65536)
        if os.stat(target).st_size != executable.size:
            raise ValueError('extracted size mismatch')
        os.chmod(target, 0o755)


def alarm_timeout(signum, frame):
    raise TimeoutError('acquisition deadline exceeded')


def timestamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    result = Path(tempfile.mkdtemp(prefix='asset.', dir=BASE))
    archive = result / 'evaluator.tar.gz'
    metadata = {'url': URL, 'expected_archive_sha256': DIGEST, 'started_utc': timestamp(), 'status': 'started'}
    print(f'evidence directory: {result}', flush=True)
    previous_handler = signal.signal(signal.SIGALRM, alarm_timeout)
    signal.setitimer(signal.ITIMER_REAL, DEADLINE_SECONDS)
    try:
        deadline = time.monotonic() + DEADLINE_SECONDS
        request = urllib.request.Request(URL, headers={'User-Agent': 'rockstream-evaluator-acquisition/1'})
        opener = urllib.request.build_opener(HTTPSRedirect())
        with opener.open(request, timeout=SOCKET_TIMEOUT) as response, archive.open('xb') as output:
            final_url = urllib.parse.urlsplit(response.geturl())
            metadata['final_host'] = final_url.hostname
            if final_url.scheme.lower() != 'https':
                raise ValueError('final URL must use HTTPS')
            actual, total = bounded_download(response, output, deadline)
        metadata.update(archive_sha256=actual, archive_bytes=total)
        if actual != DIGEST:
            raise ValueError(f'archive digest mismatch: {actual}')
        cache = result / 'rust-evaluator-v0.8.0'
        cache.mkdir(mode=0o755)
        binary = cache / 'quint_evaluator'
        extract(archive, binary)
        metadata.update(binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
                        binary_bytes=binary.stat().st_size,
                        binary_mode=oct(stat.S_IMODE(binary.stat().st_mode)), status='success')
        print('verified archive and extracted evaluator; no execution performed')
    except BaseException as exc:
        metadata.update(status='failed', error_type=type(exc).__name__)
        raise
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous_handler)
        metadata['finished_utc'] = timestamp()
        (result / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')


if __name__ == '__main__':
    main()
