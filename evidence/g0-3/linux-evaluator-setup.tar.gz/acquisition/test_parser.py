import io
from pathlib import Path
import tarfile
import tempfile
import unittest

from acquire import extract


class ArchiveTest(unittest.TestCase):
    def test_inputs(self):
        for name, kind, content, expected in [
            ('quint_evaluator', tarfile.REGTYPE, b'ELF', True),
            ('./quint_evaluator', tarfile.REGTYPE, b'ELF', True),
            ('../quint_evaluator', tarfile.REGTYPE, b'ELF', False),
            ('/quint_evaluator', tarfile.REGTYPE, b'ELF', False),
            ('x/quint_evaluator', tarfile.REGTYPE, b'ELF', False),
            ('quint_evaluator', tarfile.SYMTYPE, b'', False),
            ('quint_evaluator', tarfile.LNKTYPE, b'', False),
            ('quint_evaluator', tarfile.FIFOTYPE, b'', False),
            ('quint_evaluator', tarfile.CHRTYPE, b'', False),
            ('quint_evaluator', tarfile.REGTYPE, b'', False),
            ('other', tarfile.REGTYPE, b'ELF', False),
        ]:
            with self.subTest(name=name, kind=kind), tempfile.TemporaryDirectory() as tmp:
                archive, result = Path(tmp) / 'test.tar.gz', Path(tmp) / 'binary'
                with tarfile.open(archive, 'w:gz') as tar:
                    member = tarfile.TarInfo(name)
                    member.type = kind
                    member.size = len(content)
                    member.linkname = '../../escape'
                    tar.addfile(member, io.BytesIO(content))
                if expected:
                    extract(archive, result)
                    self.assertEqual(result.read_bytes(), content)
                else:
                    with self.assertRaises(ValueError):
                        extract(archive, result)
                    self.assertFalse(result.exists())

    def test_duplicate_and_missing(self):
        for names in [[], ['quint_evaluator', './quint_evaluator']]:
            with self.subTest(names=names), tempfile.TemporaryDirectory() as tmp:
                archive = Path(tmp) / 'test.tar.gz'
                with tarfile.open(archive, 'w:gz') as tar:
                    for name in names:
                        member = tarfile.TarInfo(name)
                        member.size = 1
                        tar.addfile(member, io.BytesIO(b'x'))
                with self.assertRaises(ValueError):
                    extract(archive, Path(tmp) / 'binary')

class BoundsTest(unittest.TestCase):
    def test_bomb(self):
        import gzip
        from acquire import MAX_TAR
        with tempfile.TemporaryDirectory() as tmp:
            archive = Path(tmp) / 'bomb.gz'
            with gzip.open(archive, 'wb') as out:
                out.write(b'0' * (MAX_TAR + 1))
            with self.assertRaises(ValueError):
                extract(archive, Path(tmp) / 'binary')

    def test_pax(self):
        with tempfile.TemporaryDirectory() as tmp:
            archive = Path(tmp) / 'pax.tar.gz'
            with tarfile.open(archive, 'w:gz', format=tarfile.PAX_FORMAT) as tar:
                member = tarfile.TarInfo('quint_evaluator')
                member.size = 1
                member.pax_headers = {'comment': 'metadata'}
                tar.addfile(member, io.BytesIO(b'x'))
            with self.assertRaises(ValueError):
                extract(archive, Path(tmp) / 'binary')

    def test_redirect_and_deadline(self):
        import urllib.request
        from acquire import HTTPSRedirect, bounded_download
        req = urllib.request.Request('https://example.org')
        with self.assertRaises(ValueError):
            HTTPSRedirect().redirect_request(req, None, 302, '', {}, 'http://example.org/file')
        with self.assertRaises(TimeoutError):
            bounded_download(io.BytesIO(b'x'), io.BytesIO(), 1, clock=lambda: 1)
        with self.assertRaises(TimeoutError):
            bounded_download(io.BytesIO(b'x'), io.BytesIO(), 1, clock=iter([0, 2]).__next__)


if __name__ == '__main__':
    unittest.main()
