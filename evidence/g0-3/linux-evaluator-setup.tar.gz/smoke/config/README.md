# Evaluator observation smoke (prepared, not run)

Purpose: exercise Quint's real `--observation` path on the unchanged frozen model with the separately acquired evaluator mounted read-only at the cache path Quint expects. The shallow observation is `s.head == 0` with max steps 1; success would show this isolated setup can evaluate this witness, not that the full checker or any G0 gate passed. The failed full run remains untouched. No retries are configured.

Proposed command, pending independent review:

```
sh /Users/grove/.p2p/evidence/rockstream-g0-3/container-prep/evaluator-observation-smoke/run.sh smoke sha256:5190102c30b439f4f4a2dfce6e99e918546614ab0d467d2775f585dd6205cf85
```

Based on the reviewed campaign launcher and inspector: network none, no host ports/socket, non-root, read-only root and inputs, 2 CPU/4 GiB limits, 512 MiB executable temporary storage, image and container inspection before start, final inspection and cleanup, and pre/post host and source manifests. The evaluator file must have SHA-256 `5482f85645f6cd9dfc19cdba8e2fe2592ff7f6a246074e96d3c770ab68cc91c7`, and must be readable/executable by the container user. The model, checker, count script, package lock and Apalache JAR hashes are checked inside the container. It captures actual observation stdout, stderr, and exit status in a unique output directory. A zero process exit does not by itself constitute a model or milestone qualification decision.

Static preparation checks: `sh -n` on both scripts and Python AST parsing passed. The smoke has not been executed.
