#!/bin/sh
set -eu
mode=${1:?full}
cd /out
export QUINT_HOME=/cache JAVA_HOME=/opt/java/openjdk TMPDIR=/tmp XDG_CACHE_HOME=/tmp/xdg-cache
export PATH="$JAVA_HOME/bin:$PATH"
export NODE_OPTIONS='--max-old-space-size=512'
test "$mode" = smoke
export _JAVA_OPTIONS='-Xmx2048m -XX:ActiveProcessorCount=2 -Duser.home=/tmp'
node --version > node-version.txt
java -version > java-version.txt 2>&1
python3 --version > python-version.txt
uname -sm > platform.txt
node /tools/node_modules/.bin/quint --version > quint-version.txt
test "$(cat node-version.txt)" = v26.13.1
grep -Eq 'version "21[.]' java-version.txt
test "$(uname -s)" = Linux
test "$(uname -m)" = aarch64
test "$(cat quint-version.txt)" = 0.34.0
sha256sum /candidate/protocol.qnt /candidate/check.sh /candidate/count-states.sh /tools/package-lock.json /cache/apalache-dist-0.62.4/apalache/lib/apalache.jar > hashes.txt
test "$(sha256sum /candidate/protocol.qnt | cut -d ' ' -f1)" = 4f052d1c73d18bce4331ab64c0706ac0bd7b0d8e50a81f12b252b1cc1c772650
test "$(sha256sum /candidate/check.sh | cut -d ' ' -f1)" = 9ff3d96d28e3f71ff930e20ba4d4c6dca98bf96b90ca87712b4844f745cef13e
test "$(sha256sum /candidate/count-states.sh | cut -d ' ' -f1)" = f0c6e65d466dcfb604c49d511650c57986884123b7c6604bf8313d9df44abaae
test "$(sha256sum /tools/package-lock.json | cut -d ' ' -f1)" = 360799e9945a369203433b09d84ef1ce8371e961e27c6e98b44b6f160b6f11dc
test "$(sha256sum /cache/apalache-dist-0.62.4/apalache/lib/apalache.jar | cut -d ' ' -f1)" = e5223915507b65cc5f1638bd037ede60f8a4fc1644aff46355779f9b05df9262
node -e 'const net=require("net"); const s=net.connect({host:"1.1.1.1",port:443}); s.setTimeout(3000); s.on("connect",()=>{s.destroy();process.exit(1)}); s.on("timeout",()=>{s.destroy();process.exit(2)}); s.on("error",e=>{console.log(e.code);process.exit(e.code==="ENETUNREACH"||e.code==="EHOSTUNREACH"?0:3)})' > network-check.txt
test -x /cache/rust-evaluator-v0.8.0/quint_evaluator
sha256sum /cache/rust-evaluator-v0.8.0/quint_evaluator > evaluator-hash.txt
test "$(cut -d ' ' -f1 evaluator-hash.txt)" = 5482f85645f6cd9dfc19cdba8e2fe2592ff7f6a246074e96d3c770ab68cc91c7
printf '%s\n' 'node /tools/node_modules/.bin/quint verify /candidate/protocol.qnt --observation "s.head == 0" --max-steps 1 --verbosity 0' > observation-command.txt
set +e
node /tools/node_modules/.bin/quint verify /candidate/protocol.qnt --observation 's.head == 0' --max-steps 1 --verbosity 0 > observation.stdout 2> observation.stderr
status=$?
set -e
printf '%s\n' "$status" > observation-status.txt
exit "$status"
