import hashlib
import json
import os
import stat
from pathlib import Path

base = Path('/Users/grove/.p2p/evidence/rockstream-g0-3/container-prep')
tools = Path('/Users/grove/.p2p/rockstream-g03-tools')
roots = [
    base / 'candidate-9ff3/protocol.qnt',
    base / 'candidate-9ff3/check.sh',
    base / 'candidate-9ff3/count-states.sh',
    tools / 'node_modules', tools / 'package-lock.json',
    tools / 'quint-home/apalache-dist-0.62.4', base / 'evaluator-observation-smoke', base / 'reviewed-image-id.txt',
    base / 'evaluator-acquisition/asset.a4imifyr/rust-evaluator-v0.8.0',
]

def emit(path):
    info = os.lstat(path)
    if stat.S_ISLNK(info.st_mode):
        row = ['symlink', str(path), os.readlink(path)]
    elif stat.S_ISREG(info.st_mode):
        h = hashlib.sha256()
        with path.open('rb') as f:
            for block in iter(lambda: f.read(1024 * 1024), b''):
                h.update(block)
        row = ['file', str(path), oct(stat.S_IMODE(info.st_mode)), h.hexdigest()]
    elif stat.S_ISDIR(info.st_mode):
        return
    else:
        raise ValueError(f'unsupported input: {path}')
    print(json.dumps(row, ensure_ascii=True, separators=(',', ':')))

def fail(error):
    raise error

for root in roots:
    if root.is_dir() and not root.is_symlink():
        for directory, dirs, files in os.walk(root, followlinks=False, onerror=fail):
            dirs.sort()
            files.sort()
            for name in dirs + files:
                emit(Path(directory) / name)
    else:
        emit(root)
