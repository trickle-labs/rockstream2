import json
import sys

path, phase, image, user, config, tools, model, check, count, out, mode, evaluator = sys.argv[1:]
with open(path) as f:
    c = json.load(f)[0]
h = c['HostConfig']
def require(ok, what):
    if not ok:
        raise ValueError(what)
require(c['Image'] == image, 'image mismatch')
require(c['Config']['User'] == user, 'user mismatch')
require(h['NetworkMode'] == 'none', 'network mismatch')
require(not h.get('PortBindings') and not c['Config'].get('ExposedPorts'), 'port exposed')
require(h['ReadonlyRootfs'] is True, 'root not read-only')
require(not h.get('Privileged'), 'privileged container')
require(not h.get('CapAdd') and not h.get('Devices'), 'unexpected privileges or devices')
require(not h.get('PidMode') or h['PidMode'] == 'private', 'host PID namespace')
require('ALL' in h['CapDrop'], 'capabilities not dropped')
require('no-new-privileges' in h['SecurityOpt'], 'privileges not restricted')
require(h['NanoCpus'] == 2_000_000_000, 'CPU limit mismatch')
require(h['Memory'] == h['MemorySwap'] == 4 * 1024**3, 'memory/swap mismatch')
require(h['PidsLimit'] == 128, 'PID limit mismatch')
require(h['Tmpfs']['/tmp'] == 'rw,nosuid,nodev,exec,size=512m,mode=1777', 'tmpfs mismatch')
mounts = {m['Destination']: m for m in c['Mounts']}
expected = {'/candidate/protocol.qnt': model, '/candidate/check.sh': check,
            '/candidate/count-states.sh': count, '/tools/node_modules': tools + '/node_modules',
            '/tools/package-lock.json': tools + '/package-lock.json',
            '/cache/apalache-dist-0.62.4': tools + '/quint-home/apalache-dist-0.62.4',
            '/cache/rust-evaluator-v0.8.0': evaluator, '/config': config, '/out': out}
require(set(mounts) == set(expected), 'mount destinations mismatch')
require(all(mounts[k]['Source'] == value for k, value in expected.items()), 'mount sources mismatch')
require(mounts['/out']['RW'] is True and all(not m['RW'] for k, m in mounts.items() if k != '/out'), 'mount write permissions mismatch')
require(c['Config']['Entrypoint'] == ['/bin/sh'], 'entrypoint mismatch')
require(c['Config']['Cmd'] == ['/config/campaign.sh', mode], 'command mismatch')
require(c['Config']['WorkingDir'] == '/out', 'working directory mismatch')
if phase == 'after':
    require(c['State']['Status'] == 'exited', 'container not exited')
    require(c['State']['ExitCode'] == 0, 'container failed')
    require(c['State']['OOMKilled'] is False, 'container OOM killed')
elif phase == 'before':
    require(c['State']['Status'] == 'created', 'container already started')
else:
    raise ValueError('unknown phase')
print('inspection passed:', phase)
