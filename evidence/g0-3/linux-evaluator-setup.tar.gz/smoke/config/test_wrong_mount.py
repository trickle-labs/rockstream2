import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class InspectionTest(unittest.TestCase):
    def test_wrong_evaluator_mount_is_rejected(self):
        image, user = 'sha256:example', '501:20'
        config, tools, model, check, count, out = ['/x/' + n for n in ('config', 'tools', 'model', 'check', 'count', 'out')]
        expected = '/x/evaluator'
        mounts = {
            '/candidate/protocol.qnt': model, '/candidate/check.sh': check,
            '/candidate/count-states.sh': count, '/tools/node_modules': tools + '/node_modules',
            '/tools/package-lock.json': tools + '/package-lock.json',
            '/cache/apalache-dist-0.62.4': tools + '/quint-home/apalache-dist-0.62.4',
            '/cache/rust-evaluator-v0.8.0': '/x/wrong-evaluator', '/config': config, '/out': out,
        }
        container = {'Image': image, 'Config': {'User': user, 'Entrypoint': ['/bin/sh'],
                     'Cmd': ['/config/campaign.sh', 'smoke'], 'WorkingDir': out},
                     'HostConfig': {'NetworkMode': 'none', 'ReadonlyRootfs': True,
                     'CapDrop': ['ALL'], 'SecurityOpt': ['no-new-privileges'],
                     'NanoCpus': 2_000_000_000, 'Memory': 4 * 1024**3,
                     'MemorySwap': 4 * 1024**3, 'PidsLimit': 128,
                     'Tmpfs': {'/tmp': 'rw,nosuid,nodev,exec,size=512m,mode=1777'}},
                     'Mounts': [{'Destination': k, 'Source': v, 'RW': k == '/out'} for k,v in mounts.items()],
                     'State': {'Status': 'created'}}
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'inspect.json'
            path.write_text(json.dumps([container]))
            run = subprocess.run([sys.executable, str(Path(__file__).with_name('inspect.py')),
                                  str(path), 'before', image, user, config, tools, model,
                                  check, count, out, 'smoke', expected], capture_output=True, text=True)
            self.assertNotEqual(run.returncode, 0)
            self.assertIn('mount sources mismatch', run.stderr)


if __name__ == '__main__':
    unittest.main()
