from pathlib import Path
import json, os, shlex, subprocess
root = Path('/Users/grove/.p2p/evidence/rockstream-g0-3/inherited-preflight-1')
quint = '/Users/grove/.p2p/rockstream-g03-tools/node_modules/.bin/quint'
model = str(root / 'protocol.qnt')
lines = (root / 'check.sh').read_text().splitlines()
cases = [line for line in lines if line.startswith('"$quint" verify "$model" ') and '--observation' in line]
(root / 'cases.json').write_text(json.dumps(cases, indent=2) + '\n')
env = dict(os.environ, QUINT_HOME='/Users/grove/.p2p/rockstream-g03-tools/quint-home', JAVA_HOME='/opt/homebrew/opt/openjdk@21')
for i, line in enumerate(cases, 1):
    work = root / f'{i:03d}'
    work.mkdir()
    args = shlex.split(line)
    args[0], args[2] = quint, model
    args += ['--server-endpoint', 'localhost:18876']
    (work / 'arguments.json').write_text(json.dumps(args, indent=2) + '\n')
    with (work / 'stdout.txt').open('wb') as stdout, (work / 'stderr.txt').open('wb') as stderr:
        result = subprocess.run(args, cwd=work, env=env, stdout=stdout, stderr=stderr)
    (work / 'status.txt').write_text(str(result.returncode) + '\n')
    print(f'{i}/{len(cases)}: {result.returncode}', flush=True)
(root / 'finished.txt').write_text(f'completed {len(cases)} invocations; inspect each status and output\n')
