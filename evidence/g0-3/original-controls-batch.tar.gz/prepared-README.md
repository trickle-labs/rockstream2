# Prepared isolated original-bound diagnostics

This is a review candidate, not an executed diagnostic. It uses the separately
reviewed image ID recorded by `container-prep/reviewed-image-id.txt` and the
same Docker isolation checked in the successful one-step smoke. The launcher
creates a fresh task-only output directory and validates the actual container
inspection before start and after exit. The mount set adds only the frozen
original check script and this control runner, both read-only. The runner
checks the frozen model, checker, Apalache jar and package-lock hashes; it
selects the ten named controls with their original invariant and depth 13.

Each control is attempted once, with individual argument, status, stdout,
stderr and raw Apalache files. A status 1 counts as an observed counterexample
only if the corresponding output contains the counterexample marker; status 0
means no counterexample was found within that bound, and other results require
investigation. Runner/container exit 0 means only that all attempts finished;
it is not a full-suite pass or gate verdict. Earlier exploratory depth-14
results and the original failed Active control remain separate.

The verifier runs in a network-none container without published ports, with
read-only root and inputs, unprivileged UID, dropped capabilities and bounded
CPU/memory/PIDs. Its executable `/tmp` is necessary for Z3 shared libraries;
it remains bounded, nosuid and nodev. The writable output directory is task
evidence. The cgroup caps total container memory; JVM and Node heaps are also
bounded. Runtime failures or OOM are infrastructure results, not passes.

Review the scripts and image identity before any execution. No full check,
model source or original checker is modified by this candidate.
