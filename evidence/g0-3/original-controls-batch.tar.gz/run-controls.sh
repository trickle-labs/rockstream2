#!/bin/sh
set -eu
base=/Users/grove/.p2p/evidence/rockstream-g0-3/container-original-controls
prep=/Users/grove/.p2p/evidence/rockstream-g0-3/container-prep
check=/Users/grove/.p2p/evidence/rockstream-g0-3/inherited-preflight-1/check.sh
tools=/Users/grove/.p2p/rockstream-g03-tools
model=/Users/grove/.p2p/evidence/rockstream-g0-3/inherited-preflight-1/protocol.qnt
image=${1:?Pass the reviewed local image ID}
case "$image" in sha256:*) ;; *) echo 'Pass an immutable image ID' >&2; exit 2 ;; esac
test "$image" = sha256:5190102c30b439f4f4a2dfce6e99e918546614ab0d467d2775f585dd6205cf85
test -f "$prep/reviewed-image-id.txt"
test "$(cat "$prep/reviewed-image-id.txt")" = "$image"
out=$(mktemp -d "$base/controls.XXXXXXXX")
printf '%s\n' "$out"
uidgid=$(id -u):$(id -g)
date -u > "$out/started.txt"
docker image inspect "$image" > "$out/image-inspect.json"
cp "$prep/reviewed-image-id.txt" "$out/reviewed-image-id.txt"
shasum -a 256 "$prep/Dockerfile" "$base/run-controls.sh" "$base/controls.py" "$base/hash-inputs.py" "$base/inspect-container.py" > "$out/config-hashes.txt"
python3 "$base/hash-inputs.py" > "$out/host-hashes-before.txt"
docker create --pull never --platform linux/arm64 --network none --read-only --cap-drop ALL --security-opt no-new-privileges --cpus 2 --memory 4g --memory-swap 4g --pids-limit 128 --user "$uidgid" --tmpfs /tmp:rw,nosuid,nodev,exec,size=512m,mode=1777 \
  --mount "type=bind,src=$model,dst=/candidate/protocol.qnt,readonly" \
  --mount "type=bind,src=$tools/node_modules,dst=/tools/node_modules,readonly" \
  --mount "type=bind,src=$tools/package-lock.json,dst=/tools/package-lock.json,readonly" \
  --mount "type=bind,src=$tools/quint-home/apalache-dist-0.62.4,dst=/cache/apalache-dist-0.62.4,readonly" \
  --mount "type=bind,src=$base/controls.py,dst=/config/controls.py,readonly" \
  --mount "type=bind,src=$check,dst=/candidate/check.sh,readonly" \
  --mount "type=bind,src=$out,dst=/out" --workdir /out --entrypoint /usr/local/bin/python3 "$image" /config/controls.py > "$out/container-id.txt"
container=$(cat "$out/container-id.txt")
cleanup() {
  cleanup_result=$?
  trap - EXIT HUP INT TERM
  set +e
  docker rm "$container" > "$out/remove.txt" 2>&1 || cleanup_result=1
  printf '%s\n' "$cleanup_result" > "$out/overall-status.txt" || cleanup_result=1
  exit "$cleanup_result"
}
trap cleanup EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
docker inspect "$container" > "$out/container-before.json"
python3 "$base/inspect-container.py" "$out/container-before.json" before "$image" "$uidgid" "$base" "$tools" "$model" "$check" "$out" > "$out/inspect-before.txt"
set +e
docker start -a "$container" > "$out/docker.stdout" 2> "$out/docker.stderr"
result=$?
set -e
printf '%s\n' "$result" > "$out/launcher-status.txt"
docker inspect "$container" > "$out/container-after.json"
python3 "$base/hash-inputs.py" > "$out/host-hashes-after.txt"
date -u > "$out/finished.txt"
test "$result" -eq 0
python3 "$base/inspect-container.py" "$out/container-after.json" after "$image" "$uidgid" "$base" "$tools" "$model" "$check" "$out" > "$out/inspect-after.txt"
cmp "$out/host-hashes-before.txt" "$out/host-hashes-after.txt"
shasum -a 256 "$prep/Dockerfile" "$base/run-controls.sh" "$base/controls.py" "$base/hash-inputs.py" "$base/inspect-container.py" > "$out/config-hashes-after.txt"
cmp "$out/config-hashes.txt" "$out/config-hashes-after.txt"
