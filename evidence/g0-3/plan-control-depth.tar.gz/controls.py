import errno
import hashlib
import json
import os
from pathlib import Path
import shlex
import socket
import subprocess

out = Path('/out')
model = Path('/candidate/protocol.qnt')
check = Path('/candidate/check.sh')
quint = '/tools/node_modules/.bin/quint'
jar = Path('/cache/apalache-dist-0.62.4/apalache/lib/apalache.jar')
lock = Path('/tools/package-lock.json')

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

require(sha(model) == '4f052d1c73d18bce4331ab64c0706ac0bd7b0d8e50a81f12b252b1cc1c772650', 'model hash mismatch')
require(sha(check) == '9ff3d96d28e3f71ff930e20ba4d4c6dca98bf96b90ca87712b4844f745cef13e', 'check hash mismatch')
require(sha(jar) == 'e5223915507b65cc5f1638bd037ede60f8a4fc1644aff46355779f9b05df9262', 'jar hash mismatch')
require(sha(lock) == '360799e9945a369203433b09d84ef1ce8371e961e27c6e98b44b6f160b6f11dc', 'lock hash mismatch')
excluded = {'bad_catalog_step', 'bad_fencing_step', 'bad_namespace_publication_step',
            'bad_page_base_step', 'bad_page_generation_step', 'bad_parent_step',
            'bad_refresh_step', 'bad_reply_step', 'bad_run_step', 'bad_unprotected_step'}
loops = [line for line in check.read_text().splitlines() if line.startswith('for control in ')]
require(len(loops) == 2, 'unexpected control loops')
controls = {}
for loop_index, line in enumerate(loops):
    tokens = shlex.split(line)
    require(tokens[:3] == ['for', 'control', 'in'] and tokens[-1] == 'do', 'control syntax')
    for item in tokens[3:-1]:
        invariant, step = item.rstrip(';').split(':')
        require(step not in controls, 'duplicate control')
        bounds = {'bad_retry_step': 19, 'bad_retry2_step': 19,
                  'bad_retry_revalidation_step': 16, 'bad_root_page_step': 16,
                  'bad_corrupt_outcome1_step': 15, 'bad_corrupt_outcome2_step': 15,
                  'bad_publish_retired_step': 19, 'bad_active_step': 14,
                  'bad_catalog_step': 14, 'bad_run_step': 14, 'bad_unprotected_step': 14,
                  'bad_fencing_step': 14, 'bad_namespace_publication_step': 14,
                  'bad_page_base_step': 14, 'bad_parent_step': 14, 'bad_refresh_step': 14,
                  'bad_reply_step': 14, 'bad_pub_mismatch1_step': 16, 'bad_pub_mismatch2_step': 16}
        controls[step] = (invariant, bounds.get(step, 13 if loop_index == 0 else 10))
require(len(controls) == 58 and len(excluded) == 10 and excluded <= controls.keys(), 'selection mismatch')
selected = set(controls) - excluded
require(len(selected) == 48, 'remaining selection mismatch')
env = dict(os.environ, QUINT_HOME='/cache', JAVA_HOME='/opt/java/openjdk', TMPDIR='/tmp',
           XDG_CACHE_HOME='/tmp/xdg-cache', _JAVA_OPTIONS='-Xmx2048m -XX:ActiveProcessorCount=2 -Duser.home=/tmp',
           NODE_OPTIONS='--max-old-space-size=512', PYTHONDONTWRITEBYTECODE='1')
env['PATH'] = '/opt/java/openjdk/bin:' + env['PATH']
with (out / 'versions.txt').open('wb') as versions:
    for args in (['node', '--version'], ['java', '-version'], ['python3', '--version'], ['node', quint, '--version'], ['uname', '-sm']):
        subprocess.run(args, env=env, stdout=versions, stderr=subprocess.STDOUT, check=True)
try:
    with socket.create_connection(('1.1.1.1', 443), timeout=3):
        raise RuntimeError('external network unexpectedly reachable')
except OSError as error:
    require(error.errno in (errno.ENETUNREACH, errno.EHOSTUNREACH), f'unexpected network check error: {error}')
    (out / 'network-check.txt').write_text(f'{error.errno}\n')
cases = []
for step in sorted(selected):
    invariant, bound = controls[step]
    args = ['node', quint, 'verify', str(model), '--invariant', invariant, '--step', step,
            '--max-steps', str(bound), '--verbosity', '0', '--server-endpoint', '127.0.0.1:18917']
    cases.append({'step': step, 'invariant': invariant, 'bound': bound, 'args': args})
(out / 'plan.json').write_text(json.dumps(cases, indent=2) + '\n')
for case in cases:
    work = out / case['step']
    work.mkdir()
    (work / 'arguments.json').write_text(json.dumps(case, indent=2) + '\n')
    with (work / 'stdout.txt').open('wb') as stdout, (work / 'stderr.txt').open('wb') as stderr:
        result = subprocess.run(case['args'], cwd=work, env=env, stdout=stdout, stderr=stderr)
    (work / 'status.txt').write_text(str(result.returncode) + '\n')
    print(case['step'], result.returncode, flush=True)
(out / 'finished.txt').write_text('Forty-eight separate attempts completed; inspect each status and log. Not a suite pass.\n')
