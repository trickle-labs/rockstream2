import hashlib
import os
from pathlib import Path

roots = [
    Path('/Users/grove/.p2p/evidence/rockstream-g0-3/inherited-preflight-1/protocol.qnt'),
    Path('/Users/grove/.p2p/rockstream-g03-tools/node_modules'),
    Path('/Users/grove/.p2p/rockstream-g03-tools/package-lock.json'),
    Path('/Users/grove/.p2p/rockstream-g03-tools/quint-home/apalache-dist-0.62.4'),
    Path('/Users/grove/.p2p/evidence/rockstream-g0-3/container-remaining-controls/controls.py'),
    Path('/Users/grove/.p2p/evidence/rockstream-g0-3/container-remaining-controls/check.sh'),
]

def emit(path):
    if path.is_symlink():
        print('LINK', path, '->', os.readlink(path))
    elif path.is_file():
        h = hashlib.sha256()
        with path.open('rb') as f:
            for block in iter(lambda: f.read(1024 * 1024), b''):
                h.update(block)
        print(h.hexdigest(), path)
    elif not path.is_dir():
        raise RuntimeError(f'unsupported or missing input: {path}')

def traversal_error(error):
    raise error

for root in roots:
    if root.is_dir() and not root.is_symlink():
        for directory, dirs, files in os.walk(root, followlinks=False, onerror=traversal_error):
            dirs.sort()
            files.sort()
            for name in dirs + files:
                emit(Path(directory) / name)
    else:
        emit(root)
