import json
import sys

path, phase, image, uidgid, base, tools, model, check, out = sys.argv[1:]
with open(path) as f:
    c = json.load(f)[0]
h = c['HostConfig']
def require(condition, message):
    if not condition:
        raise ValueError(message)

require(c['Image'] == image, 'image mismatch')
require(c['Config']['User'] == uidgid, 'user mismatch')
require(h['NetworkMode'] == 'none', 'network isolation missing')
require(not h.get('PortBindings'), 'port bindings present')
require(not c['Config'].get('ExposedPorts'), 'exposed ports present')
require(h['ReadonlyRootfs'] is True, 'root filesystem writable')
require('ALL' in h['CapDrop'], 'capabilities not dropped')
require('no-new-privileges' in h['SecurityOpt'], 'no-new-privileges missing')
require(h['NanoCpus'] == 2_000_000_000, 'CPU limit mismatch')
require(h['Memory'] == 4 * 1024**3, 'memory limit mismatch')
require(h['MemorySwap'] == 4 * 1024**3, 'swap limit mismatch')
require(h['PidsLimit'] == 128, 'PID limit mismatch')
require(h['Tmpfs']['/tmp'] == 'rw,nosuid,nodev,exec,size=512m,mode=1777', 'tmpfs mismatch')
mounts = {m['Destination']: m for m in c['Mounts']}
require(set(mounts) == {'/candidate/protocol.qnt', '/tools/node_modules',
                       '/tools/package-lock.json', '/cache/apalache-dist-0.62.4',
                       '/config/controls.py', '/candidate/check.sh', '/out'}, 'mount destinations mismatch')
require(mounts['/out']['RW'] is True, 'output mount not writable')
require(all(not m['RW'] for k, m in mounts.items() if k != '/out'), 'input mount writable')
expected = {'/candidate/protocol.qnt': model, '/tools/node_modules': tools + '/node_modules',
            '/tools/package-lock.json': tools + '/package-lock.json',
            '/cache/apalache-dist-0.62.4': tools + '/quint-home/apalache-dist-0.62.4',
            '/config/controls.py': base + '/controls.py', '/candidate/check.sh': check, '/out': out}
require(all(mounts[k]['Source'] == v for k, v in expected.items()), 'mount sources mismatch')
require(c['Config']['Entrypoint'] == ['/usr/local/bin/python3'], 'entrypoint mismatch')
require(c['Config']['Cmd'] == ['/config/controls.py'], 'command mismatch')
if phase == 'after':
    require(c['State']['Status'] == 'exited', 'container not exited')
    require(c['State']['ExitCode'] == 0, 'nonzero container status')
    require(c['State']['OOMKilled'] is False, 'container OOM killed')
elif phase != 'before':
    raise ValueError('unknown phase')
print('inspection passed:', phase)
