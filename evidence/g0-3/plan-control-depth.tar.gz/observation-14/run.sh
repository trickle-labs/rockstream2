#!/bin/sh
set -u
cd /Users/grove/.p2p/evidence/rockstream-g0-3/plan-revision-depth-14 || exit 1
export QUINT_HOME=/Users/grove/.p2p/rockstream-g03-tools/quint-home
export JAVA_HOME=/opt/homebrew/opt/openjdk@21
/Users/grove/.p2p/rockstream-g03-tools/node_modules/.bin/quint verify "$PWD/protocol.qnt" --server-endpoint localhost:18879 --no-invariant --step bad_plan_revision_step --observation 's.badPlanCommit and s.refreshed and s.preparedPlan == 1 and s.sealedPlan == 1 and s.planRevision == 2 and s.publicationHead == s.parent + 1 and s.owner == s.generation' --max-steps 14 --verbosity 0 >stdout.txt 2>stderr.txt
result=$?
printf '%s\n' "$result" >status.txt
exit "$result"
