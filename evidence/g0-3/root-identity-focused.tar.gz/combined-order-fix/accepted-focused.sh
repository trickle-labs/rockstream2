#!/bin/sh
set -u
export QUINT_HOME=/Users/grove/.p2p/rockstream-g03-tools/quint-home
export JAVA_HOME=/opt/homebrew/opt/openjdk@21
quint=/Users/grove/.p2p/rockstream-g03-tools/node_modules/.bin/quint
model=/Users/grove/.p2p/evidence/rockstream-g0-3/combined-order-fix/protocol.qnt
out=/Users/grove/.p2p/evidence/rockstream-g0-3/combined-order-fix
run() {
  name=$1; shift
  "$quint" verify "$model" --server-endpoint localhost:18873 "$@" --verbosity 0 > "$out/$name.log" 2>&1
  result=$?
  printf '%s\n' "$result" > "$out/$name.status"
}
run accepted_conflict --observation 's.clientReplyIssued and s.clientReplyKind == 2 and s.clientReplyDigest != s.clientGhostDigest and s.clientEffects == 1' --max-steps 10
run accepted_expiry --observation 's.clientReplyIssued and s.clientReplyKind == 3 and s.clientFloor == 2 and not(s.clientRetained) and s.clientEffects == 1' --max-steps 10
