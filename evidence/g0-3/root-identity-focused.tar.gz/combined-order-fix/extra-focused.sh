#!/bin/sh
set -u
export QUINT_HOME=/Users/grove/.p2p/rockstream-g03-tools/quint-home
export JAVA_HOME=/opt/homebrew/opt/openjdk@21
quint=/Users/grove/.p2p/rockstream-g03-tools/node_modules/.bin/quint
model=/Users/grove/.p2p/evidence/rockstream-g0-3/combined-order-fix/protocol.qnt
out=/Users/grove/.p2p/evidence/rockstream-g0-3/combined-order-fix
run() {
  name=$1; shift
  "$quint" verify "$model" --server-endpoint localhost:18872 "$@" --verbosity 0 > "$out/$name.log" 2>&1
  result=$?
  printf '%s\n' "$result" > "$out/$name.status"
}
run client_conflict --observation 's.clientReplyIssued and s.clientReplyKind == 2 and s.clientReplyDigest != s.clientGhostDigest' --max-steps 10
run client_rejected_replay --observation 's.clientGhostOutcome == -1 and s.clientReplyIssued and s.clientReplyKind == 1 and s.clientReplyValue == -1' --max-steps 10
