#!/bin/sh
set -u
export QUINT_HOME=/Users/grove/.p2p/rockstream-g03-tools/quint-home
export JAVA_HOME=/opt/homebrew/opt/openjdk@21
quint=/Users/grove/.p2p/rockstream-g03-tools/node_modules/.bin/quint
model=/Users/grove/.p2p/evidence/rockstream-g0-3/combined-order-fix/protocol.qnt
out=/Users/grove/.p2p/evidence/rockstream-g0-3/combined-order-fix
run() {
  name=$1
  shift
  "$quint" verify "$model" --server-endpoint localhost:18871 "$@" --verbosity 0 > "$out/$name.log" 2>&1
  result=$?
  printf '%s\n' "$result" > "$out/$name.status"
}
run race_retire --observation 's.retired and s.pinPending and s.otherUploaded and s.otherKind == 9 and s.otherBase < s.head and s.racerDone and s.racerKind == 10 and s.racerBase == s.otherBase' --max-steps 10
run race_pin --observation 's.pinned and s.retirePending and s.otherUploaded and s.otherKind == 10 and s.otherBase < s.head and s.racerDone and s.racerKind == 9 and s.racerBase == s.otherBase' --max-steps 10
run client_replay --observation 's.clientReplyIssued and s.clientReplyKind == 1 and s.clientEffects == 1 and s.clientReplyHead > s.clientGhostOutcome' --max-steps 10
run client_expiry --observation 's.clientReplyIssued and s.clientReplyKind == 3 and s.clientFloor == 2 and not(s.clientRetained)' --max-steps 10
run bad_unprotected --invariant publication --step bad_other_unprotected_step --max-steps 8
run bad_stale --invariant publication --step bad_other_stale_step --max-steps 8
run bad_generation --invariant publication --step bad_other_generation_step --max-steps 8
run bad_kind --invariant publication --step bad_other_kind_step --max-steps 8
run bad_client_expired --invariant fencing_and_outcomes --step bad_expired_accept_step --max-steps 10
run bad_root_page --invariant publication --step bad_root_page_step --max-steps 18
