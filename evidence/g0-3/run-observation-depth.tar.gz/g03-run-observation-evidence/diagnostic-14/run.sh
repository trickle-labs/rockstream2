#!/bin/sh
set -u
cd /Users/grove/.p2p/evidence/rockstream-g0-3/run-observation-depth-14 || exit 1
export QUINT_HOME=/Users/grove/.p2p/rockstream-g03-tools/quint-home
export JAVA_HOME=/opt/homebrew/opt/openjdk@21
export _JAVA_OPTIONS='-Xmx2g -XX:ActiveProcessorCount=2'
export NODE_OPTIONS='--max-old-space-size=512'
/Users/grove/.p2p/rockstream-g03-tools/node_modules/.bin/quint verify "$PWD/protocol.qnt" --server-endpoint localhost:18921 --no-invariant --step bad_run_step --observation 's.badContextCommit and s.active and s.preparedRun != s.runIncarnation and s.preparedCatalog == s.catalogRevision and not(s.badInputCommit) and not(s.badPageCommit)' --max-steps 14 --verbosity 0 >stdout.txt 2>stderr.txt
result=$?
printf '%s\n' "$result" >status.txt
exit "$result"
