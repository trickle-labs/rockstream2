#!/bin/sh
set -u
cd /Users/grove/.p2p/evidence/rockstream-g0-3/supplemental-16-step || exit 1
export QUINT_HOME="$PWD/cache"
export JAVA_HOME=/opt/homebrew/opt/openjdk@21
export _JAVA_OPTIONS='-Xmx2048m -XX:ActiveProcessorCount=2'
export NODE_OPTIONS='--max-old-space-size=512'
shasum -a 256 protocol.qnt /Users/grove/.p2p/rockstream-g03-tools/node_modules/.bin/quint cache/apalache-dist-0.62.4/apalache/lib/apalache.jar /Users/grove/.p2p/rockstream-g03-tools/package-lock.json > hashes.txt
date -u > started.txt
nice -n 10 /Users/grove/.p2p/rockstream-g03-tools/node_modules/.bin/quint verify "$PWD/protocol.qnt" --server-endpoint localhost:18917 --invariants publication fencing_and_outcomes gc --max-steps 16 --verbosity 0 >stdout.txt 2>stderr.txt
result=$?
date -u > finished.txt
printf '%s\n' "$result" > status.txt
exit "$result"
