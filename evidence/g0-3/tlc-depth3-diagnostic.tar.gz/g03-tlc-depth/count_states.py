from pathlib import Path
import collections
import hashlib
import re

raw = Path('states.txt.dump').read_text()
parts = re.split(r'(?m)^State (\d+):\n', raw)
assert parts[0] == '' and len(parts) % 2 == 1
states = []
depths = collections.Counter()
for i in range(1, len(parts), 2):
    assert int(parts[i]) == (i + 1) // 2
    match = re.fullmatch(r'/\\ s = (\[.*\])\n/\\ depth = ([0-3])\n\n', parts[i + 1], re.S)
    assert match, parts[i]
    states.append(match.group(1))
    depths[int(match.group(2))] += 1
assert len(states) == 11746
print('depth-tagged configurations:', len(states))
print('configurations by depth:', dict(sorted(depths.items())))
print('distinct printed protocol records:', len(set(states)))
print('dump SHA-256:', hashlib.sha256(raw.encode()).hexdigest())
