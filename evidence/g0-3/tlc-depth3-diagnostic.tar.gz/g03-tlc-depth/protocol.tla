------------------------------- MODULE protocol -------------------------------

EXTENDS Integers, Sequences, FiniteSets, TLC, Apalache, Variants

VARIABLE
  (*
    @type: Int;
  *)
  depth

VARIABLE
  (*
    @type: { abandonedAttempt: Int, age: Int, attempt: Int, badDataCommit: Bool, badFence: Bool, badGc: Bool, badParent: Bool, badPlanCommit: Bool, badPublication: Bool, badSealCommit: Bool, deleted: Bool, done1: Bool, done2: Bool, duplicate: Bool, effects1: Int, generation: Int, head: Int, lastAttempt: Int, metadataDone: Bool, op: Int, outcome1: Int, owner: Int, parent: Int, pinPending: Bool, pinRevision: Int, pinned: Bool, planRevision: Int, prepared: Bool, preparedGeneration: Int, preparedPlan: Int, publicationHead: Int, publications: Int, publishedDataReady: Bool, receipt1Attempt: Int, receipt1Id: Int, receipt1Object: Int, receipt1Scope: Int, receipt2Attempt: Int, receipt2Id: Int, receipt2Object: Int, receipt2Scope: Int, receipts: Set(Int), refreshed: Bool, reply1: Int, response1: Bool, retirePending: Bool, retireRevision: Int, retired: Bool, revision: Int, root: Bool, sealed: Bool, sealedAttempt: Int, sealedDuplicate: Bool, sealedOwner: Int, sealedParent: Int, sealedPlan: Int, sealedReceipt1: Int, sealedReceipt1Attempt: Int, sealedReceipt1Object: Int, sealedReceipt1Scope: Int, sealedReceipt2: Int, sealedReceipt2Attempt: Int, sealedReceipt2Object: Int, sealedReceipt2Scope: Int, sealedReceipts: Set(Int), stageClosed: Bool, stageDurabilityAdvanced: Bool, stageDurable: Bool, stageProtected: Bool, stalePublished: Bool, visible1: Bool, visible2: Bool };
  *)
  s

(*
  @type: (() => Bool);
*)
abandon ==
  s["prepared"]
    /\ s'
      := [
        [ s EXCEPT !["prepared"] = FALSE ] EXCEPT
          !["abandonedAttempt"] = s["attempt"]
      ]

(*
  @type: (() => Bool);
*)
reassign ==
  s["generation"] = 0
    /\ s["head"] < 3
    /\ s'
      := [ [ s EXCEPT !["generation"] = 1 ] EXCEPT !["head"] = s["head"] + 1 ]

(*
  @type: ((Bool) => Bool);
*)
refresh(bad_1366) ==
  s["prepared"]
    /\ s["revision"] /= s["head"]
    /\ s'
      := [
        [
          [
            [ s EXCEPT !["revision"] = s["head"] ] EXCEPT
              !["refreshed"] = TRUE
          ] EXCEPT
            !["owner"] = IF bad_1366 THEN s["generation"] ELSE s["owner"]
        ] EXCEPT
          !["sealedOwner"] =
            IF bad_1366 THEN s["generation"] ELSE s["sealedOwner"]
      ]

(*
  @type: (() => Bool);
*)
competingPublish ==
  s["prepared"]
    /\ ~(s["done2"])
    /\ ~(s["retired"])
    /\ ~(s["deleted"])
    /\ s["head"] < 3
    /\ s'
      := [
        [
          [
            [
              [
                [
                  [
                    [ s EXCEPT !["head"] = s["head"] + 1 ] EXCEPT
                      !["publicationHead"] = s["publicationHead"] + 1
                  ] EXCEPT
                    !["done2"] = TRUE
                ] EXCEPT
                  !["publications"] = s["publications"] + 1
              ] EXCEPT
                !["root"] = TRUE
            ] EXCEPT
              !["visible1"] = TRUE
          ] EXCEPT
            !["visible2"] = TRUE
        ] EXCEPT
          !["publishedDataReady"] = TRUE
      ]

(*
  @type: ((Bool) => Bool);
*)
reconcile(wrongHead_1454) ==
  s["done1"]
    /\ ~(s["response1"])
    /\ s'
      := [
        [ s EXCEPT !["response1"] = TRUE ] EXCEPT
          !["reply1"] = IF wrongHead_1454 THEN s["head"] ELSE s["outcome1"]
      ]

(*
  @type: (() => Bool);
*)
advance ==
  ~(s["metadataDone"])
    /\ s["head"] < 3
    /\ s'
      := [
        [ s EXCEPT !["head"] = s["head"] + 1 ] EXCEPT
          !["metadataDone"] = TRUE
      ]

(*
  @type: (() => Bool);
*)
changePlan ==
  s["planRevision"] = 1
    /\ s["head"] < 3
    /\ s'
      := [ [ s EXCEPT !["planRevision"] = 2 ] EXCEPT !["head"] = s["head"] + 1 ]

(*
  @type: (() => Bool);
*)
makeStageDurable ==
  s["prepared"]
    /\ s["stageProtected"]
    /\ ~(s["stageDurable"])
    /\ s'
      := [
        [ s EXCEPT !["stageDurable"] = TRUE ] EXCEPT
          !["stageDurabilityAdvanced"] = TRUE
      ]

(*
  @type: (() => Bool);
*)
closeStage ==
  s["stageProtected"]
    /\ s["head"] < 3
    /\ s'
      := [
        [
          [ s EXCEPT !["stageProtected"] = FALSE ] EXCEPT
            !["stageClosed"] = TRUE
        ] EXCEPT
          !["head"] = s["head"] + 1
      ]

(*
  @type: (() => Bool);
*)
tick == s["age"] < 2 /\ s' := [ s EXCEPT !["age"] = s["age"] + 1 ]

(*
  @type: (() => Bool);
*)
preparePin ==
  ~(s["pinPending"])
    /\ ~(s["pinned"])
    /\ ~(s["retired"])
    /\ s'
      := [
        [ s EXCEPT !["pinPending"] = TRUE ] EXCEPT
          !["pinRevision"] = s["head"]
      ]

(*
  @type: ((Bool) => Bool);
*)
prepareRetire(bad_1629) ==
  ~(s["retirePending"])
    /\ ~(s["retired"])
    /\ ~(s["pinned"])
    /\ ~(s["root"])
    /\ (~(s["stageProtected"]) \/ bad_1629)
    /\ s'
      := [
        [ s EXCEPT !["retirePending"] = TRUE ] EXCEPT
          !["retireRevision"] = s["head"]
      ]

(*
  @type: (() => Bool);
*)
refreshPin ==
  s["pinPending"]
    /\ s["pinRevision"] /= s["head"]
    /\ s' := [ s EXCEPT !["pinRevision"] = s["head"] ]

(*
  @type: (() => Bool);
*)
refreshRetire ==
  s["retirePending"]
    /\ s["retireRevision"] /= s["head"]
    /\ s' := [ s EXCEPT !["retireRevision"] = s["head"] ]

(*
  @type: ((Bool) => Bool);
*)
commitPin(bad_1732) ==
  s["pinPending"]
    /\ ~(s["pinned"])
    /\ s["head"] < 3
    /\ ((s["pinRevision"] = s["head"] /\ ~(s["retired"])) \/ bad_1732)
    /\ s'
      := [
        [
          [ [ s EXCEPT !["pinPending"] = FALSE ] EXCEPT !["pinned"] = TRUE ] EXCEPT
            !["head"] = s["head"] + 1
        ] EXCEPT
          !["badGc"] =
            (s["badGc"] \/ s["retired"]) \/ s["pinRevision"] /= s["head"]
      ]

(*
  @type: ((Bool) => Bool);
*)
commitRetire(bad_1813) ==
  s["retirePending"]
    /\ ~(s["retired"])
    /\ s["head"] < 3
    /\ ((((s["retireRevision"] = s["head"] /\ ~(s["pinned"])) /\ ~(s["root"]))
        /\ ~(s["stageProtected"]))
      \/ bad_1813)
    /\ s'
      := [
        [
          [ [ s EXCEPT !["retirePending"] = FALSE ] EXCEPT !["retired"] = TRUE ]
            EXCEPT
            !["head"] = s["head"] + 1
        ] EXCEPT
          !["badGc"] =
            (((s["badGc"] \/ s["pinned"]) \/ s["root"])
                \/ s["retireRevision"] /= s["head"])
              \/ s["stageProtected"]
      ]

(*
  @type: (() => Bool);
*)
unpin ==
  s["pinned"]
    /\ s["head"] < 3
    /\ s'
      := [ [ s EXCEPT !["pinned"] = FALSE ] EXCEPT !["head"] = s["head"] + 1 ]

(*
  @type: (() => Bool);
*)
releaseRoot ==
  s["root"]
    /\ s["head"] < 3
    /\ s'
      := [
        [
          [ [ s EXCEPT !["root"] = FALSE ] EXCEPT !["visible1"] = FALSE ] EXCEPT
            !["visible2"] = FALSE
        ] EXCEPT
          !["head"] = s["head"] + 1
      ]

(*
  @type: ((Bool) => Bool);
*)
reference(bad_1906) ==
  ~(s["root"])
    /\ s["head"] < 3
    /\ (~(s["retired"]) \/ bad_1906)
    /\ s'
      := [
        [ [ s EXCEPT !["root"] = TRUE ] EXCEPT !["head"] = s["head"] + 1 ] EXCEPT
          !["badGc"] = s["badGc"] \/ s["retired"]
      ]

(*
  @type: (() => Bool);
*)
collect ==
  s["retired"]
    /\ ~(s["pinned"])
    /\ ~(s["root"])
    /\ ~(s["deleted"])
    /\ s["age"] >= 2
    /\ s' := [ s EXCEPT !["deleted"] = TRUE ]

(*
  @type: (() => Bool);
*)
tamperReceipt ==
  s["prepared"]
    /\ s["sealed"]
    /\ s["receipt1Id"] /= 3
    /\ s' := [ s EXCEPT !["receipt1Id"] = 3 ]

(*
  @type: (() => Bool);
*)
init ==
  s
    = [head |-> 0,
      publicationHead |-> 0,
      planRevision |-> 1,
      preparedPlan |-> 1,
      generation |-> 0,
      prepared |-> FALSE,
      parent |-> 0,
      revision |-> 0,
      owner |-> 0,
      preparedGeneration |-> 0,
      refreshed |-> FALSE,
      receipts |-> {},
      duplicate |-> FALSE,
      attempt |-> 0,
      lastAttempt |-> 0,
      abandonedAttempt |-> 0,
      receipt1Attempt |-> 0,
      receipt2Attempt |-> 0,
      receipt1Id |-> 0,
      receipt2Id |-> 0,
      receipt1Object |-> 0,
      receipt2Object |-> 0,
      receipt1Scope |-> 0,
      receipt2Scope |-> 0,
      sealed |-> FALSE,
      sealedAttempt |-> 0,
      sealedParent |-> 0,
      sealedOwner |-> 0,
      sealedPlan |-> 0,
      sealedReceipt1 |-> 0,
      sealedReceipt2 |-> 0,
      sealedReceipts |-> {},
      sealedDuplicate |-> FALSE,
      sealedReceipt1Attempt |-> 0,
      sealedReceipt2Attempt |-> 0,
      sealedReceipt1Scope |-> 0,
      sealedReceipt2Scope |-> 0,
      sealedReceipt1Object |-> 0,
      sealedReceipt2Object |-> 0,
      stageDurable |-> FALSE,
      stageProtected |-> FALSE,
      stageClosed |-> FALSE,
      stageDurabilityAdvanced |-> FALSE,
      publishedDataReady |-> FALSE,
      op |-> 1,
      done1 |-> FALSE,
      done2 |-> FALSE,
      metadataDone |-> FALSE,
      effects1 |-> 0,
      publications |-> 0,
      visible1 |-> FALSE,
      visible2 |-> FALSE,
      response1 |-> FALSE,
      outcome1 |-> 0,
      reply1 |-> 0,
      pinned |-> FALSE,
      pinPending |-> FALSE,
      pinRevision |-> 0,
      retirePending |-> FALSE,
      retireRevision |-> 0,
      root |-> TRUE,
      retired |-> FALSE,
      deleted |-> FALSE,
      age |-> 0,
      stalePublished |-> FALSE,
      badDataCommit |-> FALSE,
      badPlanCommit |-> FALSE,
      badSealCommit |-> FALSE,
      badPublication |-> FALSE,
      badParent |-> FALSE,
      badFence |-> FALSE,
      badGc |-> FALSE]

(*
  @type: (() => Bool);
*)
publication ==
  (((((~(s["badDataCommit"]) /\ ~(s["badPlanCommit"])) /\ ~(s["badSealCommit"]))
          /\ ~(s["badPublication"]))
        /\ ~(s["badParent"]))
      /\ s["visible1"] = s["visible2"])
    /\ (~(s["visible1"]) \/ s["publications"] > 0)

(*
  @type: (() => Bool);
*)
fencing_and_outcomes ==
  ((~(s["stalePublished"]) /\ ~(s["badFence"])) /\ s["effects1"] <= 1)
    /\ (~(s["response1"]) \/ s["reply1"] = s["outcome1"])

(*
  @type: (() => Bool);
*)
gc ==
  (((((~(s["visible1"]) \/ s["publishedDataReady"])
            /\ (~(s["visible1"])
              \/ ((s["root"] /\ ~(s["retired"])) /\ ~(s["deleted"]))))
          /\ ~(s["badGc"]))
        /\ ~(s["deleted"] /\ (s["pinned"] \/ s["root"])))
      /\ ~(s["retired"] /\ ((s["root"] \/ s["pinned"]) \/ s["stageProtected"])))
    /\ (~(s["deleted"]) \/ s["age"] >= 2)

(*
  @type: ((Bool) => Bool);
*)
prepare(reuse_381) ==
  \E operation \in { 1, 2 }:
    \E durable \in { TRUE, FALSE }:
      \E protected \in { TRUE, FALSE }:
        ~(s["prepared"])
          /\ ~(s["retired"])
          /\ ~(s["deleted"])
          /\ ~(s["stageProtected"])
          /\ (IF reuse_381 THEN s["lastAttempt"] > 0 ELSE s["lastAttempt"] < 2)
          /\ s'
            := [
              [
                [
                  [
                    [
                      [
                        [
                          [
                            [
                              [
                                [
                                  [
                                    [
                                      [
                                        [
                                          [
                                            [
                                              [
                                                [
                                                  [
                                                    [
                                                      [
                                                        [
                                                          [
                                                            [
                                                              s EXCEPT
                                                                !["prepared"] =
                                                                  TRUE
                                                            ] EXCEPT
                                                              !["parent"] =
                                                                s[
                                                                  "publicationHead"
                                                                ]
                                                          ] EXCEPT
                                                            !["revision"] =
                                                              s["head"]
                                                        ] EXCEPT
                                                          !["owner"] =
                                                            s["generation"]
                                                      ] EXCEPT
                                                        !["preparedGeneration"] =
                                                          s["generation"]
                                                    ] EXCEPT
                                                      !["preparedPlan"] =
                                                        s["planRevision"]
                                                  ] EXCEPT
                                                    !["refreshed"] = FALSE
                                                ] EXCEPT
                                                  !["receipts"] = {}
                                              ] EXCEPT
                                                !["duplicate"] = FALSE
                                            ] EXCEPT
                                              !["attempt"] =
                                                IF reuse_381
                                                THEN s["lastAttempt"]
                                                ELSE s["lastAttempt"] + 1
                                          ] EXCEPT
                                            !["lastAttempt"] =
                                              IF reuse_381
                                              THEN s["lastAttempt"]
                                              ELSE s["lastAttempt"] + 1
                                        ] EXCEPT
                                          !["receipt1Attempt"] = 0
                                      ] EXCEPT
                                        !["receipt2Attempt"] = 0
                                    ] EXCEPT
                                      !["receipt1Id"] = 0
                                  ] EXCEPT
                                    !["receipt2Id"] = 0
                                ] EXCEPT
                                  !["receipt1Object"] = 0
                              ] EXCEPT
                                !["receipt2Object"] = 0
                            ] EXCEPT
                              !["stageDurable"] = durable
                          ] EXCEPT
                            !["stageProtected"] = protected
                        ] EXCEPT
                          !["stageClosed"] = FALSE
                      ] EXCEPT
                        !["stageDurabilityAdvanced"] = FALSE
                    ] EXCEPT
                      !["receipt1Scope"] = 0
                  ] EXCEPT
                    !["receipt2Scope"] = 0
                ] EXCEPT
                  !["sealed"] = FALSE
              ] EXCEPT
                !["op"] = operation
            ]

(*
  @type: (() => Bool);
*)
receive ==
  \E partition \in { 1, 2, 3 }:
    \E receiptAttempt \in { 1, 2 }:
      \E receiptId \in { 1, 2 }:
        \E receiptObject \in { 1, 2 }:
          \E receiptScope \in { 1, 2, 3 }:
            s["prepared"]
              /\ ~(s["sealed"])
              /\ ~(s["duplicate"])
              /\ s'
                := [
                  [
                    [
                      [
                        [
                          [
                            [
                              [
                                [
                                  [
                                    s EXCEPT
                                      !["receipts"] =
                                        s["receipts"] \union {partition}
                                  ] EXCEPT
                                    !["duplicate"] = partition \in s["receipts"]
                                ] EXCEPT
                                  !["receipt1Attempt"] =
                                    IF partition = 1 /\ ~(1 \in s["receipts"])
                                    THEN receiptAttempt
                                    ELSE s["receipt1Attempt"]
                              ] EXCEPT
                                !["receipt2Attempt"] =
                                  IF partition = 2 /\ ~(2 \in s["receipts"])
                                  THEN receiptAttempt
                                  ELSE s["receipt2Attempt"]
                            ] EXCEPT
                              !["receipt1Id"] =
                                IF partition = 1 /\ ~(1 \in s["receipts"])
                                THEN receiptId
                                ELSE s["receipt1Id"]
                          ] EXCEPT
                            !["receipt2Id"] =
                              IF partition = 2 /\ ~(2 \in s["receipts"])
                              THEN receiptId
                              ELSE s["receipt2Id"]
                        ] EXCEPT
                          !["receipt1Object"] =
                            IF partition = 1 /\ ~(1 \in s["receipts"])
                            THEN receiptObject
                            ELSE s["receipt1Object"]
                      ] EXCEPT
                        !["receipt2Object"] =
                          IF partition = 2 /\ ~(2 \in s["receipts"])
                          THEN receiptObject
                          ELSE s["receipt2Object"]
                    ] EXCEPT
                      !["receipt1Scope"] =
                        IF partition = 1 /\ ~(1 \in s["receipts"])
                        THEN receiptScope
                        ELSE s["receipt1Scope"]
                  ] EXCEPT
                    !["receipt2Scope"] =
                      IF partition = 2 /\ ~(2 \in s["receipts"])
                      THEN receiptScope
                      ELSE s["receipt2Scope"]
                ]

(*
  @type: (() => Int);
*)
expectedScope == IF s["preparedPlan"] = 1 THEN 1 ELSE 3

(*
  @type: (() => Bool);
*)
sealMatches ==
  (((((((((((((s["sealed"] /\ s["sealedAttempt"] = s["attempt"])
                            /\ s["sealedParent"] = s["parent"])
                          /\ s["sealedOwner"] = s["owner"])
                        /\ s["sealedPlan"] = s["preparedPlan"])
                      /\ s["sealedReceipt1"] = s["receipt1Id"])
                    /\ s["sealedReceipt2"] = s["receipt2Id"])
                  /\ s["sealedReceipts"] = s["receipts"])
                /\ s["sealedDuplicate"] = s["duplicate"])
              /\ s["sealedReceipt1Attempt"] = s["receipt1Attempt"])
            /\ s["sealedReceipt2Attempt"] = s["receipt2Attempt"])
          /\ s["sealedReceipt1Scope"] = s["receipt1Scope"])
        /\ s["sealedReceipt2Scope"] = s["receipt2Scope"])
      /\ s["sealedReceipt1Object"] = s["receipt1Object"])
    /\ s["sealedReceipt2Object"] = s["receipt2Object"]

(*
  @type: ((Bool, Bool, Bool, Bool, Bool, Bool, Bool, Bool, Bool, Bool) => Bool);
*)
publish(badReceipts_1280, badOwner_1280, badRetry_1280, ignoreParent_1280, ignoreRetirement_1280,
partial_1280, ignoreRevision_1280, ignoreSeal_1280, ignorePlan_1280, ignoreData_1280) ==
  s["prepared"]
    /\ (s["parent"] = s["publicationHead"] \/ ignoreParent_1280)
    /\ (s["revision"] = s["head"] \/ ignoreRevision_1280)
    /\ (s["preparedPlan"] = s["planRevision"] \/ ignorePlan_1280)
    /\ ((s["stageDurable"] /\ s["stageProtected"]) \/ ignoreData_1280)
    /\ (sealMatches \/ ignoreSeal_1280)
    /\ ((((((((s["receipts"] = { 1, 2 } /\ ~(s["duplicate"]))
                  /\ s["receipt1Attempt"] = s["attempt"])
                /\ s["receipt2Attempt"] = s["attempt"])
              /\ s["receipt1Scope"] = expectedScope)
            /\ s["receipt2Scope"] = expectedScope)
          /\ s["receipt1Object"] = 1)
        /\ s["receipt2Object"] = 1)
      \/ badReceipts_1280)
    /\ (s["owner"] = s["generation"] \/ badOwner_1280)
    /\ ((s["op"] = 1 /\ (~(s["done1"]) \/ badRetry_1280))
      \/ (s["op"] = 2 /\ ~(s["done2"])))
    /\ ((~(s["retired"]) /\ ~(s["deleted"])) \/ ignoreRetirement_1280)
    /\ s["head"] < 3
    /\ s'
      := [
        [
          [
            [
              [
                [
                  [
                    [
                      [
                        [
                          [
                            [
                              [
                                [
                                  [
                                    [
                                      [
                                        [
                                          [
                                            [
                                              s EXCEPT
                                                !["head"] = s["head"] + 1
                                            ] EXCEPT
                                              !["publicationHead"] =
                                                s["publicationHead"] + 1
                                          ] EXCEPT
                                            !["prepared"] = FALSE
                                        ] EXCEPT
                                          !["root"] = TRUE
                                      ] EXCEPT
                                        !["badGc"] =
                                          (s["badGc"] \/ s["retired"])
                                            \/ s["deleted"]
                                    ] EXCEPT
                                      !["done1"] = s["done1"] \/ s["op"] = 1
                                  ] EXCEPT
                                    !["done2"] = s["done2"] \/ s["op"] = 2
                                ] EXCEPT
                                  !["effects1"] =
                                    s["effects1"]
                                      + (IF s["op"] = 1 THEN 1 ELSE 0)
                              ] EXCEPT
                                !["publications"] = s["publications"] + 1
                            ] EXCEPT
                              !["visible1"] = TRUE
                          ] EXCEPT
                            !["visible2"] = ~partial_1280
                        ] EXCEPT
                          !["stalePublished"] =
                            s["stalePublished"]
                              \/ ((s["abandonedAttempt"] /= 0
                                  /\ s["attempt"] = s["abandonedAttempt"])
                                /\ (s["receipt1Attempt"] = s["abandonedAttempt"]
                                  \/ s["receipt2Attempt"]
                                    = s["abandonedAttempt"]))
                      ] EXCEPT
                        !["outcome1"] =
                          IF s["op"] = 1 /\ ~(s["done1"])
                          THEN s["head"] + 1
                          ELSE s["outcome1"]
                    ] EXCEPT
                      !["badSealCommit"] = s["badSealCommit"] \/ ~sealMatches
                  ] EXCEPT
                    !["badPlanCommit"] =
                      s["badPlanCommit"]
                        \/ s["preparedPlan"] /= s["planRevision"]
                ] EXCEPT
                  !["badDataCommit"] =
                    s["badDataCommit"]
                      \/ ~(s["stageDurable"] /\ s["stageProtected"])
              ] EXCEPT
                !["publishedDataReady"] =
                  s["stageDurable"] /\ s["stageProtected"]
            ] EXCEPT
              !["badParent"] =
                (s["badParent"] \/ s["parent"] /= s["publicationHead"])
                  \/ s["revision"] /= s["head"]
          ] EXCEPT
            !["badPublication"] =
              ((((((s["badPublication"] \/ s["receipts"] /= { 1, 2 })
                          \/ s["duplicate"])
                        \/ (s["receipt1Attempt"] /= s["attempt"]
                          \/ s["receipt2Attempt"] /= s["attempt"]))
                      \/ s["receipt1Scope"] /= expectedScope)
                    \/ s["receipt2Scope"] /= expectedScope)
                  \/ s["receipt1Object"] /= 1)
                \/ s["receipt2Object"] /= 1
        ] EXCEPT
          !["badFence"] =
            s["badFence"] \/ s["preparedGeneration"] /= s["generation"]
      ]

(*
  @type: (() => Bool);
*)
bounded_init == init /\ depth = 0

(*
  @type: ((Bool) => Bool);
*)
seal(badReceipts_846) ==
  s["prepared"]
    /\ ~(s["sealed"])
    /\ ((((((((s["receipts"] = { 1, 2 } /\ ~(s["duplicate"]))
                  /\ s["receipt1Attempt"] = s["attempt"])
                /\ s["receipt2Attempt"] = s["attempt"])
              /\ s["receipt1Scope"] = expectedScope)
            /\ s["receipt2Scope"] = expectedScope)
          /\ s["receipt1Object"] = 1)
        /\ s["receipt2Object"] = 1)
      \/ badReceipts_846)
    /\ s'
      := [
        [
          [
            [
              [
                [
                  [
                    [
                      [
                        [
                          [
                            [
                              [
                                [
                                  [ s EXCEPT !["sealed"] = TRUE ] EXCEPT
                                    !["sealedAttempt"] = s["attempt"]
                                ] EXCEPT
                                  !["sealedParent"] = s["parent"]
                              ] EXCEPT
                                !["sealedOwner"] = s["owner"]
                            ] EXCEPT
                              !["sealedPlan"] = s["preparedPlan"]
                          ] EXCEPT
                            !["sealedReceipt1"] = s["receipt1Id"]
                        ] EXCEPT
                          !["sealedReceipt2"] = s["receipt2Id"]
                      ] EXCEPT
                        !["sealedReceipts"] = s["receipts"]
                    ] EXCEPT
                      !["sealedDuplicate"] = s["duplicate"]
                  ] EXCEPT
                    !["sealedReceipt1Attempt"] = s["receipt1Attempt"]
                ] EXCEPT
                  !["sealedReceipt2Attempt"] = s["receipt2Attempt"]
              ] EXCEPT
                !["sealedReceipt1Scope"] = s["receipt1Scope"]
            ] EXCEPT
              !["sealedReceipt2Scope"] = s["receipt2Scope"]
          ] EXCEPT
            !["sealedReceipt1Object"] = s["receipt1Object"]
        ] EXCEPT
          !["sealedReceipt2Object"] = s["receipt2Object"]
      ]

(*
  @type: (() => Bool);
*)
q_inv == publication /\ fencing_and_outcomes /\ gc

(*
  @type: (() => Bool);
*)
step ==
  prepare(FALSE)
    \/ receive
    \/ seal(FALSE)
    \/ publish(FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE)
    \/ abandon
    \/ reassign
    \/ reconcile(FALSE)
    \/ advance
    \/ changePlan
    \/ refresh(FALSE)
    \/ makeStageDurable
    \/ closeStage
    \/ competingPublish
    \/ tick
    \/ preparePin
    \/ prepareRetire(FALSE)
    \/ refreshPin
    \/ refreshRetire
    \/ commitPin(FALSE)
    \/ commitRetire(FALSE)
    \/ unpin
    \/ releaseRoot
    \/ reference(FALSE)
    \/ collect

(*
  @type: (() => Bool);
*)
q_init == bounded_init

(*
  @type: (() => Bool);
*)
bad_seal_step ==
  step
    \/ tamperReceipt
    \/ (s["sealed"]
      /\ s["receipt1Id"] = 3
      /\ s["sealedReceipt1"] /= 3
      /\ publish(FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, TRUE, FALSE, FALSE))

(*
  @type: (() => Bool);
*)
bad_atomic_step ==
  step
    \/ publish(FALSE, FALSE, FALSE, FALSE, FALSE, TRUE, FALSE, FALSE, FALSE, FALSE)

(*
  @type: (() => Bool);
*)
bad_reuse_step == step \/ prepare(TRUE)

(*
  @type: (() => Bool);
*)
bad_publication_step ==
  step
    \/ seal(TRUE)
    \/ publish(TRUE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE)

(*
  @type: (() => Bool);
*)
bad_fencing_step ==
  step
    \/ publish(FALSE, TRUE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE)

(*
  @type: (() => Bool);
*)
bad_retry_step ==
  step
    \/ publish(FALSE, FALSE, TRUE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE)

(*
  @type: (() => Bool);
*)
bad_duplicate_step ==
  step
    \/ (s["stageDurable"]
      /\ s["stageProtected"]
      /\ s["receipt1Object"] = 1
      /\ s["receipt2Object"] = 1
      /\ s["receipts"] = { 1, 2 }
      /\ s["duplicate"]
      /\ s["receipt1Attempt"] = s["attempt"]
      /\ s["receipt2Attempt"] = s["attempt"]
      /\ s["receipt1Scope"] = expectedScope
      /\ s["receipt2Scope"] = expectedScope
      /\ seal(TRUE))
    \/ (s["stageDurable"]
      /\ s["stageProtected"]
      /\ s["receipt1Object"] = 1
      /\ s["receipt2Object"] = 1
      /\ s["receipts"] = { 1, 2 }
      /\ s["duplicate"]
      /\ s["receipt1Attempt"] = s["attempt"]
      /\ s["receipt2Attempt"] = s["attempt"]
      /\ s["receipt1Scope"] = expectedScope
      /\ s["receipt2Scope"] = expectedScope
      /\ publish(TRUE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE))

(*
  @type: (() => Bool);
*)
bad_foreign_step ==
  step
    \/ (s["preparedPlan"] = 1
      /\ s["stageDurable"]
      /\ s["stageProtected"]
      /\ s["receipt1Object"] = 1
      /\ s["receipt2Object"] = 1
      /\ s["receipts"] = { 1, 2 }
      /\ ~(s["duplicate"])
      /\ s["receipt1Scope"] = 1
      /\ s["receipt2Scope"] = 1
      /\ (s["receipt1Attempt"] /= s["attempt"]
        \/ s["receipt2Attempt"] /= s["attempt"])
      /\ seal(TRUE))
    \/ (s["preparedPlan"] = 1
      /\ s["stageDurable"]
      /\ s["stageProtected"]
      /\ s["receipt1Object"] = 1
      /\ s["receipt2Object"] = 1
      /\ s["receipts"] = { 1, 2 }
      /\ ~(s["duplicate"])
      /\ s["receipt1Scope"] = 1
      /\ s["receipt2Scope"] = 1
      /\ (s["receipt1Attempt"] /= s["attempt"]
        \/ s["receipt2Attempt"] /= s["attempt"])
      /\ publish(TRUE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE))

(*
  @type: (() => Bool);
*)
bad_missing_step ==
  step
    \/ (s["preparedPlan"] = 1
      /\ s["stageDurable"]
      /\ s["stageProtected"]
      /\ s["receipt1Object"] = 1
      /\ s["receipts"] = {1}
      /\ s["receipt1Attempt"] = s["attempt"]
      /\ s["receipt1Scope"] = 1
      /\ seal(TRUE))
    \/ (s["preparedPlan"] = 1
      /\ s["stageDurable"]
      /\ s["stageProtected"]
      /\ s["receipt1Object"] = 1
      /\ s["receipts"] = {1}
      /\ s["receipt1Attempt"] = s["attempt"]
      /\ s["receipt1Scope"] = 1
      /\ publish(TRUE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE))

(*
  @type: (() => Bool);
*)
bad_mixed_step ==
  step
    \/ (s["preparedPlan"] = 1
      /\ s["abandonedAttempt"] = 1
      /\ s["attempt"] = 2
      /\ s["stageDurable"]
      /\ s["stageProtected"]
      /\ s["receipt1Object"] = 1
      /\ s["receipt2Object"] = 1
      /\ s["receipts"] = { 1, 2 }
      /\ s["receipt1Attempt"] = 1
      /\ s["receipt2Attempt"] = 2
      /\ s["receipt1Scope"] = 1
      /\ s["receipt2Scope"] = 1
      /\ ~(s["duplicate"])
      /\ seal(TRUE))
    \/ (s["preparedPlan"] = 1
      /\ s["abandonedAttempt"] = 1
      /\ s["attempt"] = 2
      /\ s["stageDurable"]
      /\ s["stageProtected"]
      /\ s["receipt1Object"] = 1
      /\ s["receipt2Object"] = 1
      /\ s["receipts"] = { 1, 2 }
      /\ s["receipt1Attempt"] = 1
      /\ s["receipt2Attempt"] = 2
      /\ s["receipt1Scope"] = 1
      /\ s["receipt2Scope"] = 1
      /\ ~(s["duplicate"])
      /\ publish(TRUE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE))

(*
  @type: (() => Bool);
*)
bad_interval_step ==
  step
    \/ (s["preparedPlan"] = 1
      /\ s["stageDurable"]
      /\ s["stageProtected"]
      /\ s["receipt1Object"] = 1
      /\ s["receipt2Object"] = 1
      /\ s["receipts"] = { 1, 2 }
      /\ ~(s["duplicate"])
      /\ s["receipt1Attempt"] = s["attempt"]
      /\ s["receipt2Attempt"] = s["attempt"]
      /\ s["receipt1Scope"] = 2
      /\ s["receipt2Scope"] = 1
      /\ seal(TRUE))
    \/ (s["preparedPlan"] = 1
      /\ s["stageDurable"]
      /\ s["stageProtected"]
      /\ s["receipt1Object"] = 1
      /\ s["receipt2Object"] = 1
      /\ s["receipts"] = { 1, 2 }
      /\ ~(s["duplicate"])
      /\ s["receipt1Attempt"] = s["attempt"]
      /\ s["receipt2Attempt"] = s["attempt"]
      /\ s["receipt1Scope"] = 2
      /\ s["receipt2Scope"] = 1
      /\ publish(TRUE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE))

(*
  @type: (() => Bool);
*)
bad_plan_step ==
  step
    \/ (s["preparedPlan"] = 1
      /\ s["stageDurable"]
      /\ s["stageProtected"]
      /\ s["receipt1Object"] = 1
      /\ s["receipt2Object"] = 1
      /\ s["receipts"] = { 1, 2 }
      /\ ~(s["duplicate"])
      /\ s["receipt1Attempt"] = s["attempt"]
      /\ s["receipt2Attempt"] = s["attempt"]
      /\ s["receipt1Scope"] = 3
      /\ s["receipt2Scope"] = 1
      /\ seal(TRUE))
    \/ (s["preparedPlan"] = 1
      /\ s["stageDurable"]
      /\ s["stageProtected"]
      /\ s["receipt1Object"] = 1
      /\ s["receipt2Object"] = 1
      /\ s["receipts"] = { 1, 2 }
      /\ ~(s["duplicate"])
      /\ s["receipt1Attempt"] = s["attempt"]
      /\ s["receipt2Attempt"] = s["attempt"]
      /\ s["receipt1Scope"] = 3
      /\ s["receipt2Scope"] = 1
      /\ publish(TRUE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE))

(*
  @type: (() => Bool);
*)
bad_plan_revision_step ==
  step
    \/ (s["sealed"]
      /\ s["refreshed"]
      /\ s["preparedPlan"] = 1
      /\ s["sealedPlan"] = 1
      /\ s["planRevision"] = 2
      /\ s["parent"] = s["publicationHead"]
      /\ s["owner"] = s["generation"]
      /\ publish(FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, TRUE, FALSE))

(*
  @type: (() => Bool);
*)
bad_foreign_object_step ==
  step
    \/ (s["stageDurable"]
      /\ s["stageProtected"]
      /\ s["receipts"] = { 1, 2 }
      /\ ~(s["duplicate"])
      /\ s["receipt1Attempt"] = s["attempt"]
      /\ s["receipt2Attempt"] = s["attempt"]
      /\ s["receipt1Scope"] = expectedScope
      /\ s["receipt2Scope"] = expectedScope
      /\ s["receipt1Object"] = 2
      /\ s["receipt2Object"] = 1
      /\ seal(TRUE))
    \/ (s["stageDurable"]
      /\ s["stageProtected"]
      /\ s["receipts"] = { 1, 2 }
      /\ ~(s["duplicate"])
      /\ s["receipt1Attempt"] = s["attempt"]
      /\ s["receipt2Attempt"] = s["attempt"]
      /\ s["receipt1Scope"] = expectedScope
      /\ s["receipt2Scope"] = expectedScope
      /\ s["receipt1Object"] = 2
      /\ s["receipt2Object"] = 1
      /\ publish(TRUE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE))

(*
  @type: (() => Bool);
*)
bad_undurable_step ==
  step
    \/ (s["sealed"]
      /\ ~(s["stageDurable"])
      /\ s["stageProtected"]
      /\ publish(FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, TRUE))

(*
  @type: (() => Bool);
*)
bad_unprotected_step ==
  step
    \/ (s["sealed"]
      /\ s["stageDurable"]
      /\ s["stageClosed"]
      /\ ~(s["stageProtected"])
      /\ publish(FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, TRUE))

(*
  @type: (() => Bool);
*)
bad_stage_retire_step ==
  step
    \/ (~(s["prepared"])
      /\ s["abandonedAttempt"] /= 0
      /\ s["abandonedAttempt"] = s["attempt"]
      /\ s["stageProtected"]
      /\ prepareRetire(TRUE))
    \/ (~(s["prepared"])
      /\ s["abandonedAttempt"] /= 0
      /\ s["abandonedAttempt"] = s["attempt"]
      /\ s["stageProtected"]
      /\ ~(s["root"])
      /\ ~(s["pinned"])
      /\ s["retireRevision"] = s["head"]
      /\ commitRetire(TRUE))

(*
  @type: (() => Bool);
*)
bad_refresh_step == step \/ refresh(TRUE)

(*
  @type: (() => Bool);
*)
bad_revision_step ==
  step
    \/ publish(FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, TRUE, FALSE, FALSE, FALSE)

(*
  @type: (() => Bool);
*)
bad_parent_step ==
  step
    \/ publish(FALSE, FALSE, FALSE, TRUE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE)

(*
  @type: (() => Bool);
*)
bad_reply_step == step \/ reconcile(TRUE)

(*
  @type: (() => Bool);
*)
bad_pin_step == step \/ (s["retired"] /\ commitPin(TRUE))

(*
  @type: (() => Bool);
*)
bad_retire_step == step \/ (s["pinned"] /\ commitRetire(TRUE))

(*
  @type: (() => Bool);
*)
bad_publish_retired_step ==
  step
    \/ (s["retired"]
      /\ s["stageDurable"]
      /\ ~(s["stageProtected"])
      /\ publish(FALSE, FALSE, FALSE, FALSE, TRUE, FALSE, FALSE, FALSE, FALSE, TRUE))

(*
  @type: (() => Bool);
*)
bad_resurrection_step == step \/ reference(TRUE)

(*
  @type: (() => Bool);
*)
bounded_step == depth < 3 /\ step /\ depth' := depth + 1

(*
  @type: (() => Bool);
*)
q_step == bounded_step

================================================================================
