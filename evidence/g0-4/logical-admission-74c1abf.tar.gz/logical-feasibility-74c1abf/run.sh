#!/bin/bash
set -euo pipefail
repo=/Users/grove/.p2p/rockstream-g04-logical
run_dir=$(mktemp -d /Users/grove/.p2p/g04-fast.XXXXXXXX)
pg_started=0
cleanup() {
  if [ "$pg_started" -eq 1 ]; then
    pg_ctl -D "$run_dir/db" -m fast -w stop
  fi
  rm -rf -- "$run_dir"
}
trap cleanup EXIT
cd "$repo"
printf 'run_dir=%s\n' "$run_dir"
printf 'source_commit='
git rev-parse HEAD
printf 'source_tree='
git rev-parse HEAD^{tree}
git status --short
rustc -V
cargo -V
python3 --version
psql --version
initdb -D "$run_dir/db" --no-locale --encoding=UTF8 --auth=trust
pg_ctl -D "$run_dir/db" -l "$run_dir/postgres.log" -o "-k $run_dir -p 55684 -c listen_addresses=''" -w start
pg_started=1
PGHOST="$run_dir" PGPORT=55684 CARGO_TARGET_DIR="$run_dir/target" CARGO_NET_OFFLINE=true PYTHONOPTIMIZE=1 scripts/check-fast.sh
